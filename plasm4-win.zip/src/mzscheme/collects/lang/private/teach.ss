
;; Implements the Teaching languages, at least in terms of the
;; forms. The reader-level aspects of the language (e.g.,
;; case-sensitivity) are not implemented here, and the procedures are
;; in a separate module.

;; To a first approximation, this module is one big error-checking
;; routine. In other words, most of the syntax implementations are
;; straightforward, but error-checking is complex.

;; Error-message conventions:
;;  - Report errors, somewhat anthropomorphicly, in terms of "expected"
;;    versus "found" syntax.
;;  - Report errors according to a left-to-right reading; e.g., the
;;    error in `(define 1 2 3)' is "expected an identifier, found 1",
;;    not "expected two parts after `define', but found three".
;;  - Left-to-right reporting sometimes requires an explicit expression
;;    check (via `local-expand') before reporting some other error. For
;;    example, in the expression (define (f x) + 1 2), the reported
;;    error should be for a misuse of "+", not that there are two extra
;;    parts in the definition. Avoid using `local-expand' if there's
;;    no error, however.

(module teach mzscheme
  (require (lib "etc.ss")
	   (lib "list.ss")
	   (lib "math.ss"))
  (require-for-syntax "teachhelp.ss"
		      (lib "kerncase.ss" "syntax")
		      (lib "stx.ss" "syntax")
		      (lib "struct.ss" "syntax")
		      (lib "include.ss"))

  ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ;; run-time helpers
  ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

  ;; verify-boolean is inserted to check for boolean results:
  (define (verify-boolean b where)
    (if (or (eq? b #t) (eq? b #f))
	b
	(raise
	 (make-exn:application:type
	  (format "~a: question result is not true or false: ~e" where b)
	  (current-continuation-marks)
	  b
	  'boolean))))

  ;; Wrapped around uses of local-bound variables:
  (define (check-not-undefined name val)
    (if (eq? val undefined)
	(raise
	 (make-exn:variable
	  (format "local variable used before its definition: ~a" name)
	  (current-continuation-marks)
	  name))
	val))
  (define undefined (letrec ([x x]) x))

  ;; Wrapped around top-level definitions to disallow re-definition:
  (define (check-top-level-not-defined who id)
    ((with-handlers ([not-break-exn? (lambda (exn) void)])
       (let ([b (identifier-binding id)])
	 ;; if it's not top-level, raise an exn
	 (if b
	     'bad
	     ;; At top-level, might be bound to syntax or value:
	     (with-handlers ([exn:syntax? (lambda (exn) void)])
	       (eval id))))
       (lambda () (error who "cannot redefine name: ~a" (syntax-e id))))))

  ;; Wrapped around uses of top-level variables:
  (define (check-not-a-function name val)
    (if (procedure? val)
	(raise
	 (let-values ([(what something)
		       (cond
			[(struct-constructor-procedure? val)
			 (values "constructor"
				 "called with values for the structure fields")]
			[(struct-accessor-procedure? val)
			 (values "selector"
				 "applied to a structure to get the field value")]
			[else
			 (values "procedure"
				 "applied to arguments")])])
  	   (make-exn:variable
	    (format "~a is a ~a, so it must be ~a" 
		    name
		    what
		    something)
	    (current-continuation-marks)
	    name)))
	val))

  ;; For quasiquote and shared:
  (require (rename "teachprims.ss" the-cons advanced-cons))
  (require (rename "teachprims.ss" cyclic-list? cyclic-list?))

  ;; Referenced to ensure that evaluating `lambda' always
  ;; produces a new closure (instead of using a closure
  ;; that's allocated once)
  (define make-lambda-generative 5)

  ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ;; syntax implementations
  ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

  (define-syntax define-syntax-set/provide
    (lambda (stx)
      (syntax-case stx ()
	[(_ (id ...) defn ...)
	 (with-syntax ([(plain-id ...)
			(map (lambda (id)
			       (if (identifier? id)
				   id
				   (stx-car (stx-cdr id))))
			     (syntax->list (syntax (id ...))))]
		       [provided-identifiers
			(datum->syntax-object stx 'provided-identifiers)])
	   (syntax
	    (begin
	      (provide plain-id ...)
	      (define-syntax-set (id ...) 
		(define provided-identifiers (quote-syntax (id ...)))
		defn ...))))])))

  ;; The implementation of form X is defined below as X/proc. The
  ;; reason for this is to allow the implementation of Y to re-use the
  ;; implementation of X (expanding to a use of X would mangle syntax
  ;; error messages), while preserving the binding of X as the one for
  ;; the syntax definition (so that quasiquote can regonzie unquote,
  ;; etc.).

  (define-syntax-set/provide (beginner-define
			      beginner-define-struct
			      beginner-lambda
			      beginner-app
			      beginner-top
			      beginner-cond
			      beginner-if
			      beginner-and
			      beginner-or
			      beginner-quote
			      
			      intermediate-local
			      intermediate-letrec
			      intermediate-let
			      intermediate-let*
			      intermediate-recur
			      intermediate-lambda
			      intermediate-app
			      intermediate-quote
			      intermediate-quasiquote
			      intermediate-unquote
			      intermediate-unquote-splicing
			      intermediate-time

			      advanced-define
			      advanced-lambda
			      advanced-app
			      advanced-set!
			      advanced-when
			      advanced-unless
			      advanced-define-struct
			      advanced-let
			      advanced-recur
			      advanced-begin
			      advanced-begin0
			      advanced-case
			      advanced-shared
			      advanced-delay)

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; compile-time helpers
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; Raise a syntax error:
    (define (teach-syntax-error form stx detail msg . args)
      (let ([form (if (eq? form '|function call|)
		      form
		      #f)] ; extract name from stx
	    [msg (apply format msg args)])
	(if detail
	    (raise-syntax-error form msg stx detail)
	    (raise-syntax-error form msg stx))))
    
    ;; The syntax error when a form's name doesn't follow a "("
    (define (bad-use-error name stx)
      (teach-syntax-error
       name
       stx
       #f
       "found a use of `~a' that does not follow an open parenthesis"
       name))

    ;; Use for messages "expected ..., found <something else>"
    (define (something-else v)
      (let ([v (syntax-e v)])
	(cond
	 [(number? v) "a number"]
	 [(string? v) "a string"]
	 [else "something else"])))
    
    (define (ordinal n)
      (cond
       [(or (<= 11 n 13)
	    (zero? (modulo n 10))
	    (<= 4 (modulo n 10) 9))
	(format "~ath" n)]
       [(= 1 (modulo n 10))
	(format "~ast" n)]
       [(= 2 (modulo n 10))
	(format "~and" n)]
       [(= 3 (modulo n 10))
	(format "~ard" n)]))

    ;; At the top level, wrap `defn' to first check for
    ;; existing definitions of the `names'. The `names'
    ;; argument is a syntax list of identifiers.
    (define (check-definitions-new who stx names defn)
      (if (eq? (syntax-local-context) 'top-level)
	  (with-syntax ([defn defn]
			[who who])
	    (with-syntax ([(check ...)
			   (map (lambda (name)
				  (with-syntax ([name name])
				    ;; Make sure each check has the
				    ;; source location of the original
				    ;; expression:
				    (syntax/loc stx
				      (check-top-level-not-defined 'who #'name))))
				(stx->list names))])
	      (syntax/loc stx
		(begin
		  check ...
		  defn))))
	  defn))

    ;; Same as above, but for one name
    (define (check-definition-new who stx name defn)
      (check-definitions-new who stx (list name) defn))
    
    ;; Check context for a `define' before even trying to
    ;; expand
    (define (ok-definition-context)
      (or (memq (syntax-local-context) '(top-level module))
	  (and (eq? (syntax-local-context) 'internal-define)
	       ;; See `intermediate-local/proc'. 
	       ;; Is there a better strategy?
	       (expanding-for-intermediate-local))))
    (define expanding-for-intermediate-local (make-parameter #f))

    ;; Use to generate nicer error messages than direct pattern
    ;; matching. The `where' argument is an English description
    ;; of the portion of the larger expression where a single
    ;; sub-expression was expected.
    (define (check-single-expression who where stx exprs)
      (when (null? exprs)
	(teach-syntax-error
	 who
	 stx
	 #f
	 "expected an expression ~a, but nothing's there"
	 where))
      (unless (null? (cdr exprs))
	;; In case it's erroneous, to ensure left-to-right reading:
	(local-expand (car exprs) 'expression null)
	;; First expression was ok, report an error for 2nd and later:
	(teach-syntax-error
	 who
	 stx
	 (cadr exprs)
	 "expected only one expression ~a, but found ~a extra part"
	 where
	 (if (null? (cddr exprs))
	     "one"
	     "at least one"))))

    (define (check-single-result-expr exprs where enclosing-expr)
      (check-single-expression where
			       "for the function body"
			       enclosing-expr
			       exprs))

    (define keyword-list
      (append (syntax->list provided-identifiers)
	      (syntax->list (quote-syntax 
			     (#%datum
			      #%top
			      empty true false)))))

    (define (identifier/non-kw? stx)
      (and (identifier? stx)
	   (not (ormap (lambda (x) (module-identifier=? stx x))
		       keyword-list))))

    (define (something-else/kw stx)
      (if (identifier? stx)
	  "a keyword"
	  (something-else stx)))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; define (beginner)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (beginner-define/proc stx)

      (unless (or (ok-definition-context)
		  (identifier? stx))
	(teach-syntax-error
	 'define
	 stx
	 #f
	 "found a definition that is not at the top level"))
      
      (syntax-case stx ()
	;; Constant or lambda def:
	[(_ name expr)
	 (identifier/non-kw? (syntax name))
	 (let ([lam (syntax expr)])
	   (check-defined-lambda lam)
	   (syntax-case (syntax expr) (beginner-lambda)
	     ;; Well-formed lambda def:
	     [(beginner-lambda arg-seq lexpr ...)
              (syntax-property
               (check-definition-new
                'define
                stx
                (syntax name)
                (syntax-property
                 (syntax/loc stx (define (name . arg-seq) make-lambda-generative lexpr ...))
                 'stepper-define-hint
                 'lambda-define))
               'stepper-skipto
               (list syntax-e cdr syntax-e cdr car))]
	     ;; Constant def
	     [_else
              (syntax-property
               (check-definition-new
                'define
                stx
                (syntax name)
                (syntax-property
                 (syntax/loc stx (define name expr))
                 'stepper-define-hint
                 'non-lambda-define))
               'stepper-skipto
               (list syntax-e cdr syntax-e cdr car))]))]
	;; Function definition:
	[(_ name-seq expr ...)
	 (syntax-case (syntax name-seq) () [(name ...) #t][_else #f])
	 ;; name-seq is at least a sequence
	 (let ([names (syntax->list (syntax name-seq))])
	   (when (null? names)
	     (teach-syntax-error
	      'define
	      stx
	      names
	      "expected a function name for a definition, but the name is missing"))
	   (let loop ([names names][pos 0])
	     (unless (null? names)
	       (unless (identifier/non-kw? (car names))
		 (teach-syntax-error
		  'define
		  stx
		  (car names)
		  "expected a name for ~a, but found ~a"
		  (cond
		   [(zero? pos) "a function"]
		   [else (format "the function's ~a argument" (ordinal pos))])
		  (something-else/kw (car names))))
	       (loop (cdr names) (add1 pos))))
	   (when (null? (cdr names))
	     (teach-syntax-error
	      'define
	      stx
	      (syntax name-seq)
	      "expected at least one argument name after the function name, but found none"))
	   (let ([dup (check-duplicate-identifier (cdr names))])
	     (when dup
	       (teach-syntax-error
		'define
		stx
		dup
		"found an argument name that was used more than once: ~a"
		(syntax-e dup))))
	   (check-single-result-expr (syntax->list (syntax (expr ...)))
				     #f
				     stx)
           (syntax-property
            (check-definition-new 
             'define
             stx
             (car names)
             (syntax-property
              (syntax/loc stx (define name-seq expr ...))
              'stepper-define-hint
              'shortened-proc-define))
            'stepper-skipto
            (list syntax-e cdr syntax-e cdr car)))]
	;; Constant/lambda with too many or too few parts:
	[(_ name expr ...)
	 (identifier/non-kw? (syntax name))
	 (let ([exprs (syntax->list (syntax (expr ...)))])
	   (check-single-expression 'define
				    (format "after the defined name ~a"
					    (syntax-e (syntax name)))
				    stx
				    exprs))]
	;; Bad name/header:
	[(_ non-name expr ...)
	 (teach-syntax-error
	  'define
	  stx
	  (syntax non-name)
	  "expected a function name, constant name, or function header for `define', but found ~a"
	  (something-else/kw (syntax non-name)))]
	;; Missing name:
	[(_)
	 (teach-syntax-error
	  'define
	  stx
	  #f
	  "expected a function name, constant name, or function header after `define', ~
         but nothing's there")]
	[_else
	 (bad-use-error 'define stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; lambda (beginner; only works with define)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (beginner-lambda/proc stx)
      (syntax-case stx ()
	[(_ . rest)
	 (teach-syntax-error
	  'lambda
	  stx
	  #f
	  "found a `lambda' expression that is not a function definition")]
	[_else
	 (bad-use-error 'lambda stx)]))


    (define (check-defined-lambda lam)
      (syntax-case lam (beginner-lambda)
	[(beginner-lambda arg-seq lexpr ...)
	 (syntax-case (syntax arg-seq) () [(arg ...) #t][_else #f])
	 (let ([args (syntax->list (syntax arg-seq))])
	   (for-each (lambda (arg)
		       (unless (identifier/non-kw? arg)
			 (teach-syntax-error
			  'lambda
			  lam
			  arg
			  "expected a name for a function argument, but found ~a"
			  (something-else/kw arg))))
		     args)
	   (when (null? args)
	     (teach-syntax-error
	      'lambda
	      lam
	      (syntax arg-seq)
	      "expected at least one argument name in the sequence after `lambda', but found none"))
	   (let ([dup (check-duplicate-identifier args)])
	     (when dup
	       (teach-syntax-error
		'lambda
		lam
		dup
		"found an argument name that was used more than once: ~a"
		(syntax-e dup))))
	   (check-single-result-expr (syntax->list (syntax (lexpr ...)))
				     #f
				     lam)
	   'ok)]
	;; Bad lambda because bad args:
	[(beginner-lambda args . _)
	 (teach-syntax-error
	  'lambda
	  lam
	  (syntax args)
	  "expected a sequence of function arguments after `lambda', but found ~a"
	  (something-else (syntax args)))]
	;; Bad lambda, no args:
	[(beginner-lambda)
	 (teach-syntax-error
	  'lambda
	  lam
	  (syntax args)
	  "expected a sequence of function arguments after `lambda', but nothing's there")]
	[_else 'ok]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; define-struct (beginner)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    
    (define (do-define-struct stx setters? struct-info-is-useful?)
      
      (unless (or (ok-definition-context)
		  (identifier? stx))
	(teach-syntax-error
	 'define-struct
	 stx
	 #f
	 "expected an expression, but found a definition that is not at the top level"))
      
      (syntax-case stx ()
	;; First, check for a struct name:
	[(_ name . __)
	 (not (identifier/non-kw? (syntax name)))
	 (teach-syntax-error
	  'define-struct
	  stx
	  (syntax name)
	  "expected a structure type name after `define-struct', but found ~a"
	  (something-else/kw (syntax name)))]
	;; Main case (`rest' is for nice error messages):
	[(_ name_ (field_ ...) . rest)
	 (let ([name (syntax name_)]
	       [fields (syntax->list (syntax (field_ ...)))]
	       [ht (make-hash-table)])
	   (for-each
	    (lambda (field)
	      (unless (identifier? field)
		(teach-syntax-error
		 'define-struct
		 stx
		 field
		 "expected a structure field name, found ~a"
		 (something-else field)))
	      (let ([sym (syntax-e field)])
		(when (hash-table-get ht sym (lambda () #f))
		  (teach-syntax-error
		   'define-struct
		   stx
		   field
		   "found a field name that was used more than once: ~a"
		   sym))
		(hash-table-put! ht sym #t)))
	    fields)
	   (let ([rest (syntax->list (syntax rest))])
	     (unless (null? rest)
	       (teach-syntax-error
		'define-struct
		stx
		(car rest)
		"expected nothing after the field name sequence in `define-struct', ~
               but found ~a extra part"
		(if (null? (cdr rest))
		    "one"
		    "at least one"))))
	   (let ([to-define-names (let ([l (build-struct-names name fields #f (not setters?))])
				    (if struct-info-is-useful?
					;; All names:
					l
					;; Skip `struct:' name:
					(cdr l)))])
	     (with-syntax ([(to-define-name ...) to-define-names]
			   [compile-info (if struct-info-is-useful?
					     (build-struct-expand-info name fields #f (not setters?) null null)
					     (syntax
					      (lambda (stx)
						(raise-syntax-error
						 'expression
						 "expected an expression, but found a structure name"
						 stx))))])
	       (let ([defn
                      (syntax/loc stx
			 (begin
			   (define-syntaxes (name_) compile-info)
			   (define-values (to-define-name ...)
			     (let ()
			       (define-struct name_ (field_ ...) (make-inspector))
			       (values to-define-name ...)))))])
                 (syntax-property
                  (syntax-property
                   (check-definitions-new 'define-struct
                                          stx 
                                          (syntax (name_ to-define-name ...)) 
                                          defn)
                   'stepper-skip-completely 
                   #t)
                  'stepper-define-struct-hint
                  (list
                   (syntax->list (syntax (to-define-name ...)))
                   stx))))))]
	[(_ name_ something . rest)
	 (teach-syntax-error
	  'define-struct
	  stx
	  (syntax something)
	  "expected a sequence of field names after the structure type name in `define-struct', ~
         but found ~a"
	  (something-else (syntax something)))]
	[(_ name_)
	 (teach-syntax-error
	  'define-struct
	  stx
	  (syntax something)
	  "expected a sequence of field names after the structure type name in `define-struct', ~
         but nothing's there")]
	[(_)
	 (teach-syntax-error
	  'define-struct
	  stx
	  #f
	  "expected a structure type name after `define-struct', but nothing's there")]
	[_else (bad-use-error 'define-struct stx)]))

    (define (beginner-define-struct/proc stx)
      (do-define-struct stx #f #f))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; application (beginner and intermediate)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; This application form disallows rator expressions that aren't
    ;; top-level identifiers or of the form `(check-not-undefined ...)'.

    ;; The latter is probably surprising. It turns out that every use of
    ;; a `local'-bound identifier gets converted to an undefined check,
    ;; and the call to `check-not-undefined' can't be forged by the
    ;; programmer. So the pattern-match effectively recognizes uses of
    ;; `local'-bound identifiers, which are legal as rator
    ;; expressions. (`let' and `letrec' get converted to `local'.)

    (define-values (beginner-app/proc intermediate-app/proc)
      (let ([mk-app
	     (lambda (lex-ok?)
	       (lambda (stx)
		 (syntax-case stx ()
		   [(_ rator rand ...)
		    (let* ([fun (syntax rator)]
			   [undef-check? (syntax-case fun (check-not-undefined)
					   [(check-not-undefined id)
					    #t]
					   [_else #f])]
			   [lex? (and (identifier? fun)
				      (eq? 'lexical (identifier-binding fun)))])
		      (unless (and (identifier? fun) (or lex-ok? undef-check? (not lex?)))
			(teach-syntax-error
			 '|function call|
			   stx
			   fun
			   "expected a ~a after an open parenthesis, but found ~a"
			   (if lex-ok?
			       "name"
			       "defined name or a primitive operation name")
			   (if lex?
			       "a function argument name"
			       (something-else fun))))
		      ;; The following check disallows calling thunks.
		      ;; It's disabled because we need to allow calls to
		      ;; primitive thunks.
		      '(when (null? (syntax->list (syntax (rand ...))))
			 (teach-syntax-error
			  '|function call|
			    stx
			    #f
			    "expected an argument after the function name for a function call, ~
                        but nothing's there"))
		      ;; For beginner, we need to tell beginner-top that the rator is ok:
		      (with-syntax ([rator (if (and (identifier? fun)
						    (not (identifier-binding fun)))
					       ;; avoid beginner #%top:
					       (syntax/loc stx (#%top . rator))
					       ;; keep the rator as it was:
					       fun)])
			(syntax/loc stx (#%app rator rand ...))))]
		   [(_)
		    (teach-syntax-error
		     '|function call|
		       stx
		       #f
		       (format
			"expected a ~a after an open parenthesis, but nothing's there"
			(if lex-ok?
			    "name"
			    "defined name or a primitive operation name")))]
		   [_else (bad-use-error '#%app stx)])))])
	(values (mk-app #f) (mk-app #t))))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; top-level variables (beginner)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; Disallow uses of top-level variables that are not in
    ;; application positions.

    (define (beginner-top/proc stx)
      (syntax-case stx ()
        [(_ . id)
         (syntax-property
          (syntax/loc stx (check-not-a-function 'id (#%top . id)))
          'stepper-skipto
          (list syntax-e cdr syntax-e cdr cdr car))]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; cond
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (beginner-cond/proc stx)
      (syntax-case stx ()
	[(_)
	 (teach-syntax-error
	  'cond
	  stx
	  #f
	  "expected a question--answer clause after `cond', but nothing's there")]
	[(_ clause ...)
	 (let* ([clauses (syntax->list (syntax (clause ...)))]
		[check-preceding-exprs
		 (lambda (stop-before)
		   (let/ec k
		     (for-each (lambda (clause)
				 (if (eq? clause stop-before)
				     (k #t)
				     (syntax-case clause ()
				       [(question answer)
					(begin
					  (local-expand (syntax question) 'expression null)
					  (local-expand (syntax answer) 'expression null))])))
			       clauses)))])
	   (let ([checked-clauses
		  (map
		   (lambda (clause)
		     (syntax-case clause (else)
		       [(else answer)
			(let ([lpos (memq clause clauses)])
			  (when (not (null? (cdr lpos)))
			    (teach-syntax-error
			     'cond
			     stx
			     clause
			     "found an `else' clause that isn't the last clause ~
                                    in its `cond' expression"))
			  (syntax/loc clause (else answer)))]
		       [(question answer)
                        (with-syntax ([verified (syntax-property (syntax (verify-boolean question 'cond)) 'stepper-skipto (list syntax-e cdr syntax-e cdr car))])
                          (syntax/loc clause (verified answer)))]
		       [()
			(check-preceding-exprs clause)
			(teach-syntax-error
			 'cond
			 stx
			 clause
			 "expected a question--answer clause, but found an empty clause")]
		       [(question?)
			(check-preceding-exprs clause)
			(teach-syntax-error
			 'cond
			 stx
			 clause
			 "expected a clause with a question and answer, but found a clause ~
                                with only one part")]
		       [(question? answer? ...)
			(check-preceding-exprs clause)
			(let ([parts (syntax->list clause)])
			  ;; to ensure he illusion of left-ot-right checking, make sure 
			  ;; the question and first answer (if any) are ok:
			  (local-expand (car parts) 'expression null)
			  (unless (null? (cdr parts))
			    (local-expand (cadr parts) 'expression null))
			  ;; question and answer 9if any) are ok, raise a count-based exception:
			  (teach-syntax-error
			   'cond
			   stx
			   clause
			   "expected a clause with one question and one answer, but found a clause ~
                                with ~a parts"
			   (length parts)))]
		       [_else
			(teach-syntax-error
			 'cond
			 stx
			 clause
			 "expected a question--answer clause, but found ~a"
			 (something-else clause))]))
		   clauses)])
	     ;; Add `else' clause for error, if necessary:
	     (let ([clauses (let loop ([clauses checked-clauses])
			      (cond
			       [(null? clauses)
				(list
                                 (with-syntax ([err (syntax-property (syntax (error 'cond "all question results were false")) 'stepper-inserted-else #t)])
                                   (syntax/loc stx
                                     [else err])))]
			       [(syntax-case (car clauses) (else)
				  [(else . _) #t]
				  [_else #f])
				clauses]
			       [else (cons (car clauses) (loop (cdr clauses)))]))])
	       (with-syntax ([clauses clauses])
		 (syntax/loc stx (cond . clauses))))))]
	[_else (bad-use-error 'cond stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; if
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (beginner-if/proc stx)
      (syntax-case stx ()
	[(_ test then else)
         (with-syntax ([new-test (syntax-property (syntax (verify-boolean test 'if)) 'stepper-skipto (list syntax-e cdr syntax-e cdr car))])
           (syntax/loc stx
             (if new-test
                 then
                 else)))]
	[(_ . rest)
	 (let ([n (length (syntax->list (syntax rest)))])
	   (teach-syntax-error
	    'if
	    stx
	    #f
	    "expected one question expression and two answer expressions, but found ~a expression~a"
	    (if (zero? n) "no" n)
	    (if (= n 1) "" "s")))]
	[_else (bad-use-error 'if stx)]))
    
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; or, and
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define-values (beginner-or/proc beginner-and/proc)
      (let ([mk
	     (lambda (where)
	       (with-syntax ([swhere where])
		 (lambda (stx)
		   (syntax-case stx ()
		     [(_ . clauses)
		      (let ([n (length (syntax->list (syntax clauses)))])
			(when (n . < . 2)
			  (teach-syntax-error
			   where
			   stx
			   #f
			   "expected at least two expressions after `~a', but found ~a"
			   where
			   (if (zero? n) "no expressions" "only one expression")))
                        (let ([verified-clauses 
                               (map (lambda (term)
                                      (with-syntax ([term term])
                                        (syntax-property (syntax/loc stx (verify-boolean term 'swhere))
                                                         'stepper-skipto
                                                         (list syntax-e cdr syntax-e cdr car))))
                                    (syntax->list (syntax clauses)))])
                          (datum->syntax-object #'here (cons where verified-clauses) stx)))]
		     [_else (bad-use-error where stx)]))))])
	(values (mk 'or) (mk 'and))))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; quote (symbols)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (beginner-quote/proc stx)
      (syntax-case stx ()
	[(_ expr)
	 (let ([sym (syntax expr)])
	   (unless (identifier? sym)
	     (teach-syntax-error
	      'quote
	      stx
	      #f
	      "expected a name after a ', found ~a"
	      (something-else sym)))
	   (syntax/loc stx (quote expr)))]
	[_else (bad-use-error 'quote stx)]))


    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; local
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (intermediate-local/proc stx)
      (syntax-case stx ()
	[(_ (definition ...) . exprs)
	 (let ([defns (syntax->list (syntax (definition ...)))])
	   (let* ([partly-expanded-defns 
		   (map (lambda (d)
			  ;; The following parameter lets teaching-language definition
			  ;;  forms know that it's ok to expand in this internal
			  ;;  definition context.
			  (parameterize ([expanding-for-intermediate-local #t])
			    (local-expand
			     d
			     'internal-define
			     (kernel-form-identifier-list (quote-syntax here)))))
			defns)]
		  [flattened-defns
		   (let loop ([l partly-expanded-defns][origs defns])
		     (apply
		      append
		      (map (lambda (d orig)
			     (syntax-case d (begin define-values define-syntaxes)
			       ;; we don't have to check for ill-formed `define-values'
			       ;; or `define-syntaxes', because only macros can generate
			       ;; them
			       [(begin defn ...)
				(let ([l (syntax->list (syntax (defn ...)))])
				  (loop l l))]
			       [(define-values . _)
				(list d)]
			       [(define-syntaxes . _)
				(list d)]
			       [_else
				(teach-syntax-error
				 'local
				 stx
				 orig
				 "expected only definitions within the definition sequence, but found ~a"
				 (something-else orig))]))
			   l origs)))]
		  [val-defns
		   (apply
		    append
		    (map (lambda (partly-expanded)
			   (syntax-case partly-expanded (define-values)
			     [(define-values (id ...) expr)
			      (list partly-expanded)]
			     [_else
			      null]))
			 flattened-defns))]
		  [stx-defns
		   (apply
		    append
		    (map (lambda (partly-expanded)
			   (syntax-case partly-expanded (define-syntaxes)
			     [(define-syntaxes (id ...) expr)
			      (list partly-expanded)]
			     [_else
			      null]))
			 flattened-defns))]
		  [get-ids (lambda (l)
			     (apply
			      append
			      (map (lambda (partly-expanded)
				     (syntax-case partly-expanded ()
				       [(_ (id ...) expr)
					(syntax->list (syntax (id ...)))]))
				   l)))]
		  [val-ids (get-ids val-defns)]
		  [stx-ids (get-ids stx-defns)])
	     (let ([dup (check-duplicate-identifier (append val-ids stx-ids))])
	       (when dup
		 (teach-syntax-error
		  'local
		  stx
		  dup
		  "found a name that was defined locally more than once: ~a"
		  (syntax-e dup)))
	       (let ([exprs (syntax->list (syntax exprs))])
		 (check-single-expression 'local
					  "after the local definition sequence"
					  stx
					  exprs))
	       (with-syntax ([((d-v (def-id ...) def-expr) ...) val-defns]
			     [(stx-def ...) stx-defns])
		 (with-syntax ([((tmp-id ...) ...)
				;; Generate tmp-ids that at least look like the defined
				;;  ids, for the purposes of error reporting, etc.:
				(map (lambda (def-ids)
				       (map (lambda (def-id)
					      (datum->syntax-object
					       #f
					       (string->uninterned-symbol
						(symbol->string (syntax-e def-id)))))
					    (syntax->list def-ids)))
				     (syntax->list (syntax ((def-id ...) ...))))])
		   (with-syntax ([(mapping ...)
				  (apply
				   append
				   (map
				    syntax->list
				    (syntax->list
				     (syntax
				      (((define-syntaxes (def-id) 
					  (make-undefined-check
					   (quote-syntax def-id)
					   (quote-syntax check-not-undefined)
					   (quote-syntax tmp-id)))
					...)
				       ...)))))])
		     (syntax/loc stx
		       (let ()
			 mapping ...
			 stx-def ...
			 (define-values (tmp-id ...) def-expr)
			 ...
			 . exprs))))))))]
	[(_ def-non-seq . __)
	 (teach-syntax-error
	  'local
	  stx
	  (syntax def-non-seq)
	  "expected a parenthesized definition sequence after `local', but found ~a"
	  (something-else (syntax def-non-seq)))]
	[(_)
	 (teach-syntax-error
	  'local
	  stx
	  #f
	  "expected a parenthesized definition sequence after `local', but nothing's there")]
	[_else (bad-use-error 'local stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; letrec and let (intermediate)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; For the `let' forms, match the definitely correct patterns, and
    ;; put all error checking in `bad-let-form'.

    (define (intermediate-letrec/proc stx)
      (syntax-case stx ()
	[(_ ([name rhs-expr] ...) expr)
	 (let ([names (syntax->list (syntax (name ...)))])
	   (and (andmap identifier/non-kw? names)
		(not (check-duplicate-identifier names))))
	 (with-syntax ([(rhs-expr ...) (map allow-local-lambda 
					    (syntax->list (syntax (rhs-expr ...))))])
	   (syntax/loc stx
	     (intermediate-local [(define-values (name) rhs-expr) ...] expr)))]
	[_else (bad-let-form 'letrec stx stx)]))

    (define (intermediate-let/proc stx)
      (syntax-case stx ()
	[(_ ([name rhs-expr] ...) expr)
	 (let ([names (syntax->list (syntax (name ...)))])
	   (and (andmap identifier/non-kw? names)
		(not (check-duplicate-identifier names))))
	 (with-syntax ([(tmp ...)
			(generate-temporaries (syntax (name ...)))]
		       [(rhs-expr ...) (map allow-local-lambda 
					    (syntax->list (syntax (rhs-expr ...))))])
	   (syntax/loc stx
	     (let ([tmp 
		    ;; Use `name' to preserve inferred names:
		    (let ([name rhs-expr])
		      name)]
		   ...)
	       ;; Use `local' to tell `#%app' about the bindings:
	       (intermediate-local [(define-values (name ...) (values tmp ...))]
		    expr))))]
	[_else (bad-let-form 'let stx stx)]))

    (define (intermediate-let*/proc stx)
      (syntax-case stx ()
	[(_ () expr)
	 (syntax (let () expr))]
	[(_ ([name0 rhs-expr0] [name rhs-expr] ...) expr)
	 (let ([names (syntax->list (syntax (name0 name ...)))])
	   (andmap identifier/non-kw? names))
	 (with-syntax ([rhs-expr0 (allow-local-lambda (syntax rhs-expr0))])
	   (syntax/loc stx
	     (intermediate-let ([name0 rhs-expr0])
	       (intermediate-let* ([name rhs-expr]
				   ...)
		   expr))))]
	[_else (bad-let-form 'let* stx stx)]))

    ;; Helper function: allows `beginner-lambda' instead
    ;; of rejecting it:
    (define (allow-local-lambda stx)
      (syntax-case stx (beginner-lambda)
	[(beginner-lambda . rest)
	 (begin
	   (check-defined-lambda stx)
	   ;; pattern-match again to pull out the formals:
	   (syntax-case stx ()
	     [(_ formals . rest)
	      (syntax/loc stx (lambda formals make-lambda-generative . rest))]))]
	[_else stx]))

    ;; Helper function:
    (define (bad-let-form who stx orig-stx)
      (syntax-case stx ()
	[(_ (binding ...) . exprs)
	 (let ([bindings (syntax->list (syntax (binding ...)))])
	   (for-each (lambda (binding)
		       (syntax-case binding ()
			 [(name expr)
			  (let ([name (syntax name)])
			    (unless (identifier/non-kw? name)
			      (teach-syntax-error
			       who
			       orig-stx
			       name
			       "expected a name for a local binding, but found ~a"
			       (something-else/kw name))))]
			 [(name . exprs)
			  (identifier/non-kw? (syntax name))
			  (check-single-expression who
						   (format "after the name `~a'"
							   (syntax-e (syntax name)))
						   binding
						   (syntax->list (syntax exprs)))]
			 [(something . exprs)
			  (teach-syntax-error
			   who
			   orig-stx
			   (syntax something)
			   "expected a name after the parenthesis for a ~a local definition, but found ~a"
			   who
			   (something-else/kw (syntax something)))]
			 [_else
			  (teach-syntax-error
			   who
			   orig-stx
			   binding
			   "expected a parenthesized name and expression for a ~a local definition, but found ~a"
			   who
			   (something-else binding))]))
		     bindings)
	   (unless (eq? who 'let*)
	     (let ([dup (check-duplicate-identifier (map (lambda (binding)
							   (syntax-case binding ()
							     [(name . _) (syntax name)]))
							 bindings))])
	       (when dup
		 (teach-syntax-error
		  who
		  orig-stx
		  dup
		  "found a name that was defined locally more than once: ~a"
		  (syntax-e dup)))))
	   (let ([exprs (syntax->list (syntax exprs))])
	     (check-single-expression who 
				      "after the name-defining sequence"
				      orig-stx
				      exprs)))]
	[(_ binding-non-seq . __)
	 (teach-syntax-error
	  who
	  orig-stx
	  (syntax binding-non-seq)
	  "expected a parenthesized sequence of local name definitions after `~a', but found ~a"
	  who
	  (something-else (syntax binding-non-seq)))]
	[(_)
	 (teach-syntax-error
	  who
	  orig-stx
	  #f
	  "expected a sequence of local name definitions after `~a', but nothing's there"
	  who)]
	[_else
	 (bad-use-error who stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; recur (intermediate and advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; We can defer some error reporting to `bad-let-form',
    ;; but not all of it.

    (define-values (intermediate-recur/proc advanced-recur/proc)
      (let ([mk
	     (lambda (empty-ok?)
	       (lambda (stx)
		 (syntax-case stx ()
		   [(_ fname ([name rhs-expr] ...) expr)
		    (and (identifier/non-kw? (syntax fname))
			 (let ([names (syntax->list (syntax (name ...)))])
			   (and (andmap identifier/non-kw? names)
				(or empty-ok? (pair? names))
				(not (check-duplicate-identifier names)))))
		    (syntax/loc stx
		      ((intermediate-letrec ([fname
					      (lambda (name ...)
						expr)])
					    fname)
		       rhs-expr ...))]
		   [(_form fname empty-seq . rest)
		    (and (not empty-ok?)
			 (identifier/non-kw? (syntax fname))
			 (null? (syntax-e (syntax empty-seq))))
		    (teach-syntax-error
		     'recur
		     stx
		     (syntax empty-seq)
		     "expected a non-empty sequence of bindings after the function name, ~
                    but found an empty sequence")]
		   [(_form fname . rest)
		    (identifier/non-kw? (syntax fname))
		    (bad-let-form 'recur (syntax (_form . rest)) stx)]
		   [(_form fname . rest)
		    (teach-syntax-error
		     'recur
		     stx
		     #f
		     "expected a function name after `recur', but found ~a"
		     (something-else/kw (syntax fname)))]
		   [(_form)
		    (teach-syntax-error
		     'recur
		     stx
		     #f
		     "expected a function name after `recur', but nothing's there")]
		   [_else
		    (bad-use-error 'recur stx)])))])
	(values (mk #f) (mk #t))))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; lambda (intermediate)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (intermediate-lambda/proc stx)
      (syntax-case stx ()
	[(_ arg-seq lexpr ...)
	 (syntax-case (syntax arg-seq) () [(arg ...) #t][_else #f])
	 (let ([args (syntax->list (syntax arg-seq))])
	   (for-each (lambda (arg)
		       (unless (identifier/non-kw? arg)
			 (teach-syntax-error
			  'lambda
			  stx
			  arg
			  "expected a name for a function argument, but found ~a"
			  (something-else/kw arg))))
		     args)
	   (when (null? args)
	     (teach-syntax-error
	      'lambda
	      stx
	      (syntax arg-seq)
	      "expected at least one argument name in the sequence after `lambda', but found none"))
	   (let ([dup (check-duplicate-identifier args)])
	     (when dup
	       (teach-syntax-error
		'lambda
		stx
		dup
		"found an argument name that is used more than once: ~a"
		(syntax-e dup))))
	   (check-single-expression 'lambda
				    "within lambda"
				    stx
				    (syntax->list (syntax (lexpr ...))))
	   (syntax/loc stx (lambda arg-seq lexpr ...)))]
	;; Bad lambda because bad args:
	[(_ args . __)
	 (teach-syntax-error
	  'lambda
	  stx
	  (syntax args)
	  "expected a sequence of function arguments after `lambda', but found ~a"
	  (something-else (syntax args)))]
	[(_)
	 (teach-syntax-error
	  'lambda
	  stx
	  #f
	  "expected a sequence of argument names after `lambda', but nothing's there")]
	[_else
	 (bad-use-error 'lambda stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; quote (intermediate)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define intermediate-quote/proc
      (lambda (stx)
	(syntax-case stx ()
	  [(_ expr ...)
	   (begin
	     (check-single-expression 'quote
				      "after the `quote' keyword"
				      stx
				      (syntax->list (syntax (expr ...))))
	     (syntax (quote expr ...)))]
	  [_else (bad-use-error 'quote stx)])))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; quasiquote (intermediate)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; This quasiquote uses the right cons, and perhaps provides more
    ;; suitable error messages. The "right" cons is actually advanced-cons,
    ;; because it works with shared:

    (define (intermediate-quasiquote/proc stx)
      (let loop ([stx (syntax-case stx ()
			[(_ stx) (syntax stx)]
			[(_ . any)
			 (teach-syntax-error
			  'quasiquote
			  stx
			  #f
			  "misuse of `quasiquote'")]
			[_else (bad-use-error 'quasiquote stx)])]
		 [depth 0])
	(syntax-case stx (intermediate-unquote intermediate-unquote-splicing intermediate-quasiquote)
	  [(intermediate-unquote x)
	   (if (zero? depth)
	       (syntax x)
	       (with-syntax ([x (loop (syntax x) (sub1 depth))]
			     [uq (stx-car stx)])
		 (syntax/loc stx (list (quote uq) x))))]
	  [intermediate-unquote
	   (teach-syntax-error
	    'quasiquote
	    stx
	    #f
	    "misuse of `unquote' within a quasiquoting backquote")]
	  [((intermediate-unquote-splicing x) . rest)
	   (if (zero? depth)
	       (with-syntax ([rest (loop (syntax rest) depth)])
		 (syntax (append x rest)))
	       (with-syntax ([x (loop (syntax x) (sub1 depth))]
			     [rest (loop (syntax rest) depth)]
			     [uq-splicing (stx-car (stx-car stx))])
		 (syntax-property (syntax/loc stx (the-cons (list (quote uq-splicing) x) rest))
                                  'stepper-hint
                                  'quasiquote-the-cons-application)))]
	  [intermediate-unquote-splicing
	   (teach-syntax-error
	    'quasiquote
	    stx
	    #f
	    "misuse of ,@ or `unquote-splicing' within a quasiquoting backquote")]
	  [(intermediate-quasiquote x)
	   (with-syntax ([x (loop (syntax x) (add1 depth))]
			 [qq (stx-car stx)])
	     (syntax/loc stx (list (quote qq) x)))]
	  [(a . b)
	   (with-syntax ([a (loop (syntax a) depth)]
			 [b (loop (syntax b) depth)])
	     (syntax-property (syntax/loc stx (the-cons a b))
                              'stepper-hint
                              'quasiquote-the-cons-application))]
	  [any
	   (syntax/loc stx (quote any))])))

    (define (intermediate-unquote/proc stx)
      (teach-syntax-error
       'unquote
       stx
       #f
       "misuse of a comma or `unquote', not under a quasiquoting backquote"))
    
    (define (intermediate-unquote-splicing/proc stx)
      (teach-syntax-error
       'unquote-splicing
       stx
       #f
       "misuse of ,@ or `unquote-splicing', not under a quasiquoting backquote"))
    
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; time
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (intermediate-time/proc stx)
      (syntax-case stx ()
	[(_ . exprs)
	 (check-single-expression 'time 
				  "after `time'"
				  stx
				  (syntax->list (syntax exprs)))
	 (syntax/loc stx (time . exprs))]
	[_else
	 (bad-use-error 'time stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; define (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (advanced-define/proc stx)
      ;; Handle the case that doesn't fit into beginner, then dispatch to beginner
      (syntax-case stx ()
	[(_ (name) expr)
	 (and (identifier/non-kw? (syntax name))
	      (ok-definition-context))
	 (check-definition-new
	  'define
	  stx
	  (syntax name)
	  (syntax/loc stx (define (name) expr)))]
	[(_ . rest)
	 ;; Call transformer beginner-define/proc.
	 ;; Note that we call the transformer instead of producing
	 ;; new syntax object that is a `beginner-define' form;
	 ;; that's important for syntax errors, so that they
	 ;; report `advanced-define' as the source.
	 (beginner-define/proc stx)]
	[_else
	 (bad-use-error 'define stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; lambda (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (advanced-lambda/proc stx)
      (syntax-case stx ()
	[(_  (name ...) . exprs)
	 (let ([names (syntax->list (syntax (name ...)))])
	   (for-each (lambda (name)
		       (unless (identifier/non-kw? name)
			 (teach-syntax-error
			  'lambda
			  stx
			  name
			  "expected a name for an argument, but found ~a"
			  (something-else/kw name))))
		     names)
	   (let ([dup (check-duplicate-identifier names)])
	     (when dup
	       (teach-syntax-error
		'lambda
		stx
		dup
		"found an argument name that is used more than once: ~a"
		(syntax-e dup))))
	   (check-single-expression 'lambda 
				    "after the argument-name sequence"
				    stx
				    (syntax->list (syntax exprs)))
	   (syntax/loc stx (lambda (name ...) . exprs)))]
	[(_ arg-non-seq . exprs)
	 (teach-syntax-error
	  'lambda
	  stx
	  (syntax arg-non-seq)
	  "expected a parenthesized sequence of argument names after `lambda', but found ~a"
	  (something-else (syntax arg-non-seq)))]
	[(_)
	 (teach-syntax-error
	  'lambda
	  stx
	  #f
	  "expected a sequence of argument names after `lambda', but nothing's there")]
	[_else
	 (bad-use-error 'lambda stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; application (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (advanced-app/proc stx)
      (syntax-case stx ()
	[(_ rator rand ...)
	 (syntax/loc stx (#%app rator rand ...))]
	[(_)
	 (teach-syntax-error
	  '|function call|
	    stx
	    #f
	    "expected a defined name or a primitive operation name after an ~
         open parenthesis, but nothing's there")]
	[_else (bad-use-error '#%app stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; set! (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; We disallow set!s on lambda-bound variables, which we recognize
    ;; as lexically-bound variables that are not bound to
    ;; set!-transformer syntax values.

    (define (advanced-set!/proc stx)
      (syntax-case stx ()
	[(_ id expr ...)
	 (identifier? (syntax id))
	 (let ([exprs (syntax->list (syntax (expr ...)))])
	   ;; Check that id isn't syntax, and not lexical:
	   (when ((with-handlers ([not-break-exn? (lambda (exn) (lambda () #t))])
		    ;; First try syntax:
		    (let ([binding (syntax-local-value (syntax id))])
		      ;; If it's a transformer binding, then it can take care of itself...
		      (if (set!-transformer? binding)
			  (lambda () #f) ;; no lex check wanted
			  (lambda ()
			    (teach-syntax-error
			     'set!
			     stx
			     (syntax id)
			     "expected a defined name after `set!', but found a keyword"))))))
	     ;; Now try lexical:
	     (when (eq? 'lexical (identifier-binding (syntax id)))
	       (teach-syntax-error
		'set!
		stx
		(syntax id)
		"expected a defined name after `set!', but found a function argument name")))
	   (check-single-expression 'set!
				    "for the new value"
				    stx
				    exprs)
	   (syntax/loc stx (set! id expr ...)))]
	[(_ id . __)
	 (teach-syntax-error
	  'set!
	  stx
	  (syntax id)
	  "expected a defined name after `set!', but found ~a"
	  (something-else (syntax id)))]
	[(_)
	 (teach-syntax-error
	  'set!
	  stx
	  (syntax id)
	  "expected a defined name after `set!', but nothing's there")]
	[_else (bad-use-error 'set! stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; when and unless (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    
    (define-values (advanced-when/proc advanced-unless/proc)
      (let ([mk
	     (lambda (who target-stx)
	       (lambda (stx)
		 (syntax-case stx ()
		   [(_ q expr ...)
		    (let ([exprs (syntax->list (syntax (expr ...)))])
		      (check-single-expression who
					       (format "for the answer in `~a'"
						       who)
					       stx
					       exprs)
		      (with-syntax ([who who]
				    [target target-stx])
			(syntax/loc stx (target (verify-boolean q 'who) expr ...))))]
		   [(_)
		    (teach-syntax-error
		     who
		     stx
		     #f
		     "expected a question expression after `~a', but nothing's there"
		     who)]
		   [_else
		    (bad-use-error who stx)])))])
	(values (mk 'when (quote-syntax when))
		(mk 'unless (quote-syntax unless)))))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; define-struct (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (advanced-define-struct/proc stx)
      (do-define-struct stx #t #t))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; let (advanced)       >> mz errors in named case <<
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (advanced-let/proc stx)
      (syntax-case stx ()
	[(_ name ids body)
	 (identifier/non-kw? (syntax name))
	 (syntax/loc stx (let name ids body))]
	[(_ name . rest)
	 (identifier/non-kw? (syntax name))
	 (teach-syntax-error
	  'let
	  stx
	  #f
	  "bad syntax for named `let'")]
	[(_ . rest)
	 (syntax/loc stx (intermediate-let . rest))]
	[_else
	 (bad-use-error 'let stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; begin (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    
    ;; Mask out the top-level begin
    (define (advanced-begin/proc stx)
      (syntax-case stx ()
	[(_)
	 (teach-syntax-error
	  'begin
	  stx
	  #f
	  "expected a sequence of expressions after `begin', but nothing's there")]
	[(_ e ...)
	 (syntax/loc stx (let () e ...))]
	[_else
	 (bad-use-error 'begin stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; begin0 (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    
    (define (advanced-begin0/proc stx)
      (syntax-case stx ()
	[(_)
	 (teach-syntax-error
	  'begin
	  stx
	  #f
	  "expected a sequence of expressions after `begin0', but nothing's there")]
	[(_ e ...)
	 (syntax/loc stx (begin0 e ...))]
	[_else
	 (bad-use-error 'begin0 stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; case
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define (advanced-case/proc stx)
      (syntax-case stx ()
	[(_)
	 (teach-syntax-error
	  'case
	  stx
	  #f
	  "expected an expression after `case', but nothing's there")]
	[(_ expr)
	 (teach-syntax-error
	  'case
	  stx
	  #f
	  "expected a choices--answer clause after the expression following `case', but nothing's there")]
	[(_ v-expr clause ...)
	 (let ([clauses (syntax->list (syntax (clause ...)))])
	   (for-each
	    (lambda (clause)
	      (syntax-case clause (else)
		[(else answer ...)
		 (let ([lpos (memq clause clauses)])
		   (when (not (null? (cdr lpos)))
		     (teach-syntax-error
		      'case
		      stx
		      clause
		      "found an `else' clause that isn't the last clause ~
                                    in its `case' expression"))
		   (let ([answers (syntax->list (syntax (answer ...)))])
		     (check-single-expression 'case
					      "for the answer in a case clause"
					      clause
					      answers)))]
		[(choices answer ...)
		 (let ([choices (syntax choices)]
		       [answers (syntax->list (syntax (answer ...)))])
		   (syntax-case choices ()
		     [(elem ...)
		      (let ([elems (syntax->list (syntax (elem ...)))])
			(for-each (lambda (e)
				    (let ([v (syntax-e e)])
				      (unless (or (number? v)
						  (symbol? v))
					(teach-syntax-error
					 'case
					 stx
					 e
					 "expected a name (for a symbol) or a number as a choice value, but found ~a"
					 (something-else e)))))
				  elems))]
		     [_else (teach-syntax-error
			     'case
			     stx
			     choices
			     "expected a parenthesized sequence of choice values, but found ~a"
			     (something-else choices))])
		   (when (stx-null? choices)
		     (teach-syntax-error
		      'case
		      stx
		      choices
		      "expected at least once choice in a parenthesized sequence of choice values, but nothing's there"))
		   (check-single-expression 'case
					    "for the answer in a `case' clause"
					    clause
					    answers))]
		[()
		 (teach-syntax-error
		  'case
		  stx
		  clause
		  "expected a choices--answer clause, but found an empty clause")]
		[_else
		 (teach-syntax-error
		  'case
		  stx
		  clause
		  "expected a choices--answer clause, but found ~a"
		  (something-else clause))]))
	    clauses)
	   ;; Add `else' clause for error, if necessary:
	   (let ([clauses (let loop ([clauses clauses])
			    (cond
			     [(null? clauses)
			      (list
			       (syntax/loc stx
				 [else (error 'cases "the expression matched none of the choices")]))]
			     [(syntax-case (car clauses) (else)
				[(else . _) #t]
				[_else #f])
			      clauses]
			     [else (cons (car clauses) (loop (cdr clauses)))]))])
	     (with-syntax ([clauses clauses])
	       (syntax/loc stx (case v-expr . clauses)))))]
	[_else (bad-use-error 'case stx)]))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; delay (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    (define advanced-delay/proc
      (lambda (stx)
	(syntax-case stx ()
	  [(_ expr ...)
	   (begin
	     (check-single-expression 'delay
				      "after the `delay' keyword"
				      stx
				      (syntax->list (syntax (expr ...))))
	     (syntax (delay expr ...)))]
	  [_else (bad-use-error 'delay stx)])))

    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
    ;; shared (advanced)
    ;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ;; We do all the initial syntax checks, and otherwise
    ;; let "shared-body.ss" implement the form.

    (define advanced-shared/proc
      (lambda (stx)
	;; Helper for the main implementation
	(define (make-check-cdr name)
	  (with-syntax ([name name])
	    (syntax (unless (cyclic-list? (cdr name))
		      (raise-type-error
		       'cons
		       "list or cyclic list"
		       1
		       (car name)
		       (cdr name))))))

	;; Check the syntax before letting the main implementation go:
	(syntax-case stx ()
	  [(_ (binding ...) . exprs)
	   (let ([bindings (syntax->list (syntax (binding ...)))])
	     (for-each
	      (lambda (binding)
		(syntax-case binding ()
		  [(id . exprs)
		   (identifier/non-kw? (syntax id))
		   (check-single-expression 'shared
					    "after the binding name"
					    binding
					    (syntax->list (syntax exprs)))]
		  [(a . rest)
		   (not (identifier/non-kw? (syntax a)))
		   (teach-syntax-error
		    'shared
		    stx
		    (syntax a)
		    "expected a name for the binding, but found ~a"
		    (something-else/kw (syntax a)))]
		  [()
		   (teach-syntax-error
		    'shared
		    stx
		    (syntax a)
		    "expected a name for a binding, but nothing's there")]
		  [_else
		   (teach-syntax-error
		    'shared
		    stx
		    binding
		    "expected a name--expression pair for a binding, but found ~a"
		    (something-else binding))]))
	      bindings)
	     (check-single-expression 'shared
				      "after the bindings"
				      stx
				      (syntax->list (syntax exprs))))]
	  [(_ bad-bind . exprs)
	   (teach-syntax-error
	    'shared
	    stx
	    (syntax bad-bind)
	    "expected a sequence of bindings after `shared', but found ~a"
	    (something-else (syntax bad-bind)))]
	  [(_)
	   (teach-syntax-error
	    'shared
	    stx
	    (syntax bad-bind)
	    "expected a sequence of bindings after `shared', but nothing's there")]
	  [_else (bad-use-error 'shared stx)])

	;; The main implementation
	(include (build-path up up "mzlib" "private" "shared-body.ss"))))))
