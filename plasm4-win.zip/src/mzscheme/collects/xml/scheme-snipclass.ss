(module scheme-snipclass mzscheme
  (require "private/xml-snip-helpers.ss"
           (lib "class.ss")
           (lib "mred.ss" "mred"))
  
  (provide snip-class)

  (define scheme-snip%
    (class* editor-snip% (scheme-snip<%> readable-snip<%>)
      (init-field splice?)
      (define/public (get-splice?) splice?)

      (define/public (read-one-special index file line col pos)
        (scheme-read-one-special this
                                 file
                                 line
                                 col
                                 pos))
      
      (super-instantiate ())))
  
  (define scheme-snipclass%
    (class snip-class%
      (define/override (read stream-in)
        (let* ([splice? (zero? (send stream-in get-exact))]
               [snip (instantiate scheme-snip% ()
                       (splice? splice?))])
          (send (send snip get-editor) read-from-file stream-in)
          snip))
      (super-instantiate ())))
  
  (define snip-class (make-object scheme-snipclass%))
  (send snip-class set-version 1)
  (send snip-class set-classname (format "~s" '(lib "scheme-snipclass.ss" "xml")))
  (send (get-the-snip-class-list) add snip-class))