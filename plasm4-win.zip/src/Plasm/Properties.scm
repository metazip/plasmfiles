;==================================================
; MzPlasm
; Author:
;     Stefano Francesi
;     Simone Portuesi
; DATE:  June 2001
; ADDED: Properties to any Plasm Object
;==================================================
; Scheme should only use these functions
; The actual implementation of these functions 
; depends on the actual implementation of SimplexN properties

(define (make-hash-assoc-weak)
  (let ((storage (make-hash-table)))
    (lambda args
	
      (case (list-ref args 0)

	('get (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)))

	('assoc `(,(list-ref args 1) 
                  ,(hash-table-get storage (list-ref args 1) (lambda () #f))))

	('bound (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�) #f #t))

	('del (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�)
                   #f 
                   (begin 
                     (hash-table-remove! storage (list-ref args 1))
                     #t)))

	('set (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�)
                   #f 
                   (begin
                     (hash-table-put! storage (list-ref args 1) (list-ref args 2))
                     #t)))

	('create (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�)
                      (begin
                        (hash-table-put! storage (list-ref args 1) (list-ref args 2))
                        #t)
                      #f))

	('put  (begin
                (hash-table-put! storage (list-ref args 1) (list-ref args 2))
                #t))

	('storage storage)

	('list (hash-table-map storage (lambda (k v) (cons k v))))


	(else #f)))))

(define global-properties (make-hash-assoc-weak))

(define (get-gp obj . opt)
  (let ((objprps (global-properties 'get obj))
	(name (aref opt 0)))
    (if (eq? objprps '�_np_�) 
	'�_np_�
	(if (void? name)
	    (objprps 'list)
	    (objprps 'get (string->symbol name)))
	)))
	
	    


(define (add-gp obj name value)
  (let ((name2 (string->symbol name))
	(objprps (global-properties 'get obj)))
    (if (eq? objprps '�_np_�) 
	(begin 
	  (global-properties 'create obj (make-hash-assoc))
	  (set! objprps  (global-properties 'get obj))))
    (objprps 'put name2 value)))
	



(define (set-gp obj name value)
  
  (global-properties 'put obj (make-hash-assoc))
  (let ((objprps (global-properties 'get obj (make-hash-assoc)))
	(name (string->symbol name)))
    (objprps 'put name value)))
  




(define (list-gp . opt)
  (let ((obj  (aref opt 0)))
    (if (void? obj) 
	(map (lambda (assoc)
		   `(,(car assoc)
		     ,((cdr assoc) 'list)))
		 (global-properties 'list))
	(let* ((objprps (global-properties 'get obj)))
	  ; insert here get-prop from polc
	  (if (eq? objprps '�_np_�) 
	      '()
	      (objprps 'list)))
)))
	
; Return properties of obj in pairs format
(define (plasm-list-gp obj)
  (map (lambda (pair) `(,(symbol->string (car pair)) ,(cdr pair))) (list-gp obj)))

; Test property presence
(define (has-property? obj)
	(not (null? `(,(list-gp obj)))))
