;; ----------------------------------------------
;; Author Giorgio Scorzelli
;; EMAIL scr.giorgio@cogesic.it
;; Date April 2001
;; Remote plasm client for Java GUI
;; ----------------------------------------------


; -----------------------------------
; Utils for String
; -----------------------------------
(define (string-left buffer left)
  (if (< (string-length buffer) left)
      ""
      (substring buffer 0 left)))

(define (string-right buffer right)
  (if (< (string-length buffer) right)
      ""
      (substring buffer (- (string-length buffer) right) (string-length buffer))))


; -----------------------------------
; main thread
; ----------------------------------
(define remote-plasm-web-mode        #f)
(define remote-plasm-socket-mode     #f)
(define remote-plasm-mzplasm-www-url "")
(define remote-plasm-processo        #f)
(define remote-plasm-direct-out      #f)
(define remote-plasm-port-number     -1)
(define remote-plasm-number-of-file   0)
(define remote-plasm-prompt-cmd-count 0)


; -----------------------------------
; a request to execute a command
; ----------------------------------
(define (start-evaluation exp)
  (set! remote-plasm-processo 
    (thread 
      (lambda () 
        (begin
					(eval-plasm exp)
          (display (string-append "MzPlasm [" (number->string remote-plasm-prompt-cmd-count) "]> "))
          (set! remote-plasm-prompt-cmd-count (+ 1 remote-plasm-prompt-cmd-count))
          (newline))))))

         

; ----------------------------------
; a request to save a file
; ----------------------------------

(define (create-tmp-base-name extension)
  (begin
    (set! remote-plasm-number-of-file (+ 1 remote-plasm-number-of-file))
    (string-append (format "session_~a_~a" remote-plasm-port-number remote-plasm-number-of-file) extension)))

(define (create-tmp-name basefilename)
  (build-path (current-directory) "tmp" basefilename))
  
(define (url-to-client url)
	(string-append "<url>" url "</url>"))

(define (save-tmp-file data extension)
  (let* 
    (
     (basefilename (create-tmp-base-name extension))
     (filename (create-tmp-name basefilename))
     (f (open-output-file filename))
    )

    (display data f)
    (close-output-port f)

    (display (url-to-client (string-append remote-plasm-mzplasm-www-url "tmp/" basefilename)) remote-plasm-direct-out)
		(flush-output remote-plasm-direct-out)))
  

; ----------------------------------
;; send a url
; ----------------------------------
(define my-display-buffer "")

(define my-display-pure-port
  (lambda (port)
    (set! my-display-buffer "")
    (let loop ()
      (let ((c (read-char port)))
        (unless (eof-object? c)
          (set! my-display-buffer (string-append my-display-buffer (make-string 1 c)))
          (loop))))
    (close-input-port port)))

(define (send-complete-url url)
  (if remote-plasm-socket-mode
		(my-display-pure-port (open-input-file url))
  		(call/input-url (string->url url) get-pure-port my-display-pure-port))

  (display 
   (string-append 
    "<data>" 
    "<url>" 
		url 
		"</url>"
    my-display-buffer
    "</data>" )
   remote-plasm-direct-out) 
  (flush-output remote-plasm-direct-out))



; ----------------------------------
; is the buffer complete?
; ----------------------------------

(define my-error-handler
  (lambda (exn) 
    (display "ERROR::" (current-error-port)) 
    (display (exn-message exn) (current-error-port))
    (newline (current-error-port)) 
    #t));; delete current command from buffer!


(define (check-input buffer)
  (cond
    
    ;; evaluate an expression
    ((and (equal? (string-left buffer 6) "<eval>") (equal? (string-right buffer 7) "</eval>"))
			(start-evaluation (substring buffer 6 (- (string-length buffer) 7))))
    
    ;; Exit from program
    ((and (equal? (string-left buffer 6) "<exit>") (equal? (string-right buffer 7) "</exit>"))
     (exit))

    ;; save file in tmp directory
    ((and (equal? (string-left buffer 6) "<save>") (equal? (string-right buffer 7) "</save>"))
			(with-handlers ([exn? my-error-handler])
				(save-tmp-file (substring buffer 6 (- (string-length buffer) 7)) ".psm")))

		;; request for a file (url)
    ((and (equal? (string-left buffer 5) "<url>") (equal? (string-right buffer 6) "</url>"))
			(with-handlers ([exn? my-error-handler])
				(send-complete-url (substring buffer 5 (- (string-length buffer) 6)))))
    
    ;; no continue to accumulate
    (else #f)))

; ----------------------------------
; read from input port
; ----------------------------------
(define (filter-proc in out buffer)
  
  (define ch (read-char in))
  
  (cond
    
    ;EOF
    ((or (eof-object? ch) (eq? ch (integer->char 4)))
     (close-output-port out))
    
    ;C-c
    ((eq? (integer->char 3) ch)
     ;; interrompi processo
     (if (and (thread? remote-plasm-processo) (thread-running? remote-plasm-processo)) (break-thread remote-plasm-processo))
     (set! remote-plasm-processo #f)
     (filter-proc in out ""))
    
    ;OTHER
    (else
     (set! buffer (string-append buffer (make-string 1 ch)))
     (if (check-input buffer )
         (filter-proc in out "")
         (filter-proc in out buffer)))))

; -----------------------------------------
; start a scheme server
; -----------------------------------------

(define (make-socket-output-port out) 
  (make-output-port 
    (lambda(s) (display "<msg>" out) (display s out) (display "</msg>" out) (flush-output out)) 
    (lambda() #t)))

(define (make-socket-error-port out) 
  (make-output-port 
    (lambda(s) (display "<error>" out) (display s out) (display "</error>" out) (flush-output out)) 
    (lambda() #t)))

(define (start-plasm-server port)
  (let ([l (tcp-listen port)])
    (let-values ([(r w) (tcp-accept l)])
      (set! remote-plasm-port-number port)
      (current-output-port (make-socket-output-port w))
      (current-error-port  (make-socket-error-port w))
      (set! remote-plasm-direct-out w)
      (display "<msg>" remote-plasm-direct-out) 
			(welcome remote-plasm-direct-out) 
			(display "</msg>" remote-plasm-direct-out) 
			(flush-output remote-plasm-direct-out)
      (filter-proc r w ""))))
