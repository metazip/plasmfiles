;==================================================
; MzPlasm
; Author:
;     Simone Portuesi
; Revision:
;     Giorgio Scorzelli
;     Stefano Francesi 
; DATE:  January 2001
; REVISION:  August 2001
; ADDED: Name support inside environment
;        (not so pure reference to geometry)
;==================================================

; aref function i-th element of a list|vector|string if present, #f otherwise
(define (aref what i) (cond ((and (string? what) (< i (string-length what)))
			     (string-ref what i))
			    ((and (list? what) (< i (length what)))
			     (list-ref what i))
			    ((and (vector? what) (< i (vector-length what)))
			     (vector-ref what i))))

; curried aref
(define c_aref (lambda (i) (lambda (what) (aref what i))))


; Stefano Francesi - Name support inside environment
; Defined here, maybe a better place ...
(define insert_name (lambda (arg)
	(send (aref arg 0) set-name-pol-complex (symbol->string (aref arg 1)))
	))

; Stefano Francesi - Unloading unnecessary complexes
; Defined here, maybe a better place ...
(define delete_polcomplex (lambda (pol)
	(send pol delete-pol-complex)
	))

; class function of association list class 
; (define assoc-list (make-list-assoc init_assoc_list))
;
; should be subclass of a generic association class
;
; method          | return value                       | side effect    
; ----------------------------------------------------------
; 'get  name      | element value or '�_np_�           | none
; 'assoc name     | assoc pair or #f                   | none
; 'bound name     | #t or #f                           | none
; 'del name       | #t or #f                           | deletes elem
; 'set name val   | #t or #f                           | sets if present
; 'create name val| #t or #f                           | creates if not present
; 'put name val   | #t                                 | sets or creates
; 'list           | list of assoc pairs                | none
; 'storage        | storage assoc list                 | none
; otherwise : error or #f?
;
; name must be a symbol
; value anyvalue except �_np_� symbol
;
; note thet get returns the  �_np_� symbol as it is rare one wants to store 
;      such a value

(define (make-list-assoc . init)
  (let* ((storage init))
      (lambda args
	(let ((fun (aref args 0))
	      (name (aref args 1))
	      (value (aref args 2)))
	
	  (case fun
	    
	    ('get (let ((binding (assq name storage)))
		    (if binding 
			(cdr binding) 
			'�_np_�))) 
	    
	    ('assoc (assq name storage))
	    
	    ('bound (if (assq name storage) #t #f))
	    
	    ('del 
	     (let* ((binding (assq name storage))
		    (remain (memq binding storage)))
	       (if binding 
		   (begin (set-car! remain (list #t)) #t)
		       #f 
		       )))
	    
	    ('set 
	     (let ((binding (assq name storage)))
	       (if binding 
		   (begin 
		     (set-cdr! binding (if value value '()))
		     #t)
		   #f 
		   ))) 
	    
	    ('create 
	     (let ((binding (assq name storage))
		   (first-empty (assq #t storage)))
	       (if binding #f
		   (begin 
		     (if first-empty 
			 (begin 
			       (set-car! first-empty name)
			       (set-cdr! first-empty (if value value '())))
			 (if value 
			     (set! storage (cons (cons name value) storage))
			     (set! storage (cons (list name) storage))))
		     #t))))
	    
	    ('put 
	     (let ((binding (assq name storage))
		   (first-empty (assq #t storage)))
	       (if binding (set-cdr! binding  (if value value '()))
		   (if first-empty 
		       (begin 
			 (set-car! first-empty name)
			 (set-cdr! first-empty  (if value  value '())))
		       (if value 
			   (set! storage (cons (cons name value) storage))
			   (set! storage (cons (list name) storage)))))
	       #t))

	    ('list 
	     (do ((res '() (if (eq? (car (car todo)) #t) 
			       res 
			       (cons  (car todo) res)))
		  (todo storage (cdr todo)))
		 ((null? todo) res)))
	    
	    ('storage storage)
	    
	    (else #f))
	  
	     ))))

; class function of association hash class 
; (define assoc-hash (make-list-assoc size_hash_table))
; should be subclass of a generic association class
;
; implemented as hash of assoc list
;
; method         | return value                       | side effect    
; ----------------------------------------------------------
; 'get           | element value or '�_np_�           | none
; 'assoc         | assoc pair or #f                   | none
; 'bound         | #t or #f                           | none
; 'del           | #t or #f                           | deletes elem
; 'set           | #t or #f                           | sets if present
; 'create        | #t or #f                           | creates if not present
; 'put           | #t                                 | sets or creates
; 'list          | list of assoc pairs                | none
; 'storage       | storage hash                       | none
; otherwise : error or #f?
;
; name must be a symbol
; value anyvalue except �_np_� symbol
;
; note thet get returns the  �_np_� symbol as it is rare one wants to store 
;      such a value

(define (make-hash-assoc)
  (let ((storage (make-hash-table)))
    (lambda args
	
      (case (list-ref args 0)

	('get (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)))

	('assoc `(,(list-ref args 1) 
                  ,(hash-table-get storage (list-ref args 1) (lambda () #f))))

	('bound (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�) #f #t))

	('del (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�)
                   #f 
                   (begin 
                     (hash-table-remove! storage (list-ref args 1))
                     #t)))

	('set (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�)
                   #f 
                   (begin
                     (hash-table-put! storage (list-ref args 1) (list-ref args 2))
                     #t)))

	('create (if (eq? (hash-table-get storage (list-ref args 1) (lambda () '�_np_�)) '�_np_�)
                      (begin
                        (hash-table-put! storage (list-ref args 1) (list-ref args 2))
                        #t)
                      #f))

	('put  (begin
                (hash-table-put! storage (list-ref args 1) (list-ref args 2))
                #t))

	('storage storage)

	('list (hash-table-map storage (lambda (k v) (cons k v))))


	(else #f)))))

; plasm definition class function


(define (make-def  expr_ . optarg)
  (let ((expr expr_)
	(value '�_np_�)
	(name (if (void? (aref optarg 0)) '�_np_� (aref optarg 0)))
	(used (make-list-assoc))
	(uses (make-list-assoc)))
    (letrec 
	((this
    
	  (lambda arg

	    (if (null? arg) (set! arg '(value)))
	   (case (aref arg 0)
	     
	     ('value 
	      (if being_used_by
		  (begin
		    (used 'put (aref being_used_by 0))
		    ((aref being_used_by 1) 'put this)
		    ))
	      
	      (if (eq? value '�_np_�) 
	     
		  (let ((being_used_by_old being_used_by))
		    (set! value (lambda (arg) (value arg)))
		    ;(set! value (lambda () (value)))
		    (set! being_used_by `(,this ,uses))
		    (let ((ret (call-with-current-continuation 
			   (lambda (exception_h)
			     (fluid-let (
					;(error-handler 
					;(lambda arg (exception_h (cons 'Scheme_error arg))))
				
					 (plasm-exception 
					  (lambda (arg) (exception_h (cons 'Plasm_exception arg)))))
			       (set! value (expr))
			       `(Plasm_value ,value))))))

		      (set! being_used_by being_used_by_old)
		     
		      (if (eq? (car ret) 'Plasm_exception) 
			  (begin
					    (set! value '�_np_�)
					    (plasm-exception (cdr ret))))
			  
		      ; Aggiunte Stefano Francesi
		      ; se value e' un complesso poliedrale, allora gli associo il nome 
		      (if (pol-complex? value) (insert_name (list value name)))
					
		      value))
		     
		  value
		  ))
	     
	     ('reset (if value
			 (begin
					
		       ; Aggiunte Stefano Francesi 
  			   ; se value e' un complesso poliedrale provo a deallocarlo
			   (if (and *FREE-UNUSED-MEMORY* (pol-complex? value))
					(begin (delete_polcomplex value) 
						  ;(collect-garbage)
					))
			   (set! value '�_np_�)
			   (for-each (lambda (id)
					
					;(((*env* 'get-def (car id)) 'used) 'del name)
				       (((car id) 'used) 'del this)
				       (uses 'del (car id)))
				     (uses 'list))
			   (for-each (lambda (id)
					
					;((*env* 'get-def (car id)) 'reset)
				       ((car id) 'reset)
				       (used 'del (car id)))
				     (used 'list))
		      )
		    #t))
	     ('set (if value (this 'reset))
		   (set! name (if (void? (aref arg 2)) 
				  '�_np_�
				  (aref arg 2))
			 )
		   (set! expr (aref arg 1)))
	     ('name name)
	     ('this this)
	     ('storage `(,name ,this ,expr ,value ,used ,uses ))
	     ('list `(,name ,this ,expr ,value ,(used 'list) ,(uses 'list)))
	     ('value_stored value)
	     ('expr expr)
	     ('used used)
	     ('uses uses)
	     (else #f)
	     ))))
    this)))

(define (make-val-def expr_ . optarg)
  (let ((value (expr_))
	(name (if (void? (aref optarg 0)) (aref optarg 0)  '�_np_�)))
    (letrec 
	((this
	  (lambda arg
	    (if (null? arg) (set! arg '(value)))
	    (case (aref arg 0)
	      ('value value)
	      ('name name)
	      ('set (if (aref arg 2) 
		       (set! name (aref arg 2))
		       (set! name '�_np_�))
		    	(set! value (aref arg 1)))
	      ('reset #t)
	      ('storage `(,name ,this ,value))
	      ('list `(,name ,this ,value))
	      (else #f)
	))))
      this)))


(define (make-fun-def expr_ . optarg)
  (let ((expr expr_)
	(name (if (void? (aref optarg 0)) (aref optarg 0)  '�_np_�)))
    (letrec 
	((this_f
	  (lambda arg
	    (if (null? arg) (set! arg '(value)))
	    (case (aref arg 0)
	      ('value (expr))
		  ('name name)
	      ('set (if (aref arg 2) 
		       (set! name (aref arg 2))
		       (set! name '�_np_�))
				(set! expr arg))
	      ('reset #t)
	      ('storage `(,name ,this ,expr))
	      ('list `(,name ,this ,expr))
	      (else #f)
	      ))))
      this_f)))


(define (make-env mkdef storage)
 (lambda args
      (let ((fun (aref args 0))
	    (name (aref args 1))
	    (expr (aref args 2)))
	(case fun 
	  ('get 
	   (let ((def (storage 'get name)))
	     (if (eq? def '�_np_�) '�_np_� (def 'value))))

	  ('get-def (storage 'get name))

	  ('def 
	   (let ((def (storage 'get name)))
		  (if (eq? def '�_np_�)
		      (storage 'create name (mkdef expr name))
		      (begin
			(def 'reset)
			(def 'set expr name)))
		  name
		  ))

	  ('list (map (lambda (elem) `(,(car elem) ,(if (pair? elem) ((cdr elem) 'list) '())))
		      (storage 'list)))
	  ('storage storage)
	  (else #f)
))))




(define (make-list-env) (make-env make-def (make-list-assoc)))

(define (make-hash-env) (make-env make-def (make-hash-assoc)))

(define (dom-env env)
  (map (lambda (elem) (car elem)) (env 'list)))

(define (add-env env1 env2)
 
    (lambda args 
      (let ((fun (aref args 0))
	    (name (aref args 1))
	    (expr (aref args 2)))
	(case fun 
	  ('def
	   (env1 'def name expr))
	  

	  ('get 
	       (let ((e1 (env1 'get-def name))  
		     (e2 (env2 'get-def name)))
		 (if (eq? e1 '�_np_�) 
		     (if (eq? e2 '�_np_�) '�_np_� (e2 'value)) 
		     (e1 'value))))
	  
	  
	  ('get-def 
	   (let ((e1 (env1 'get-def name))  
		 (e2 (env2 'get-def name)))
	     (if (eq? e1 '�_np_�) e2 e1)))
	  
	  ('list (append (env1 'list) (env2 'list)))
	  ('storage (list (env1 'storage)  (env2 'storage))) 
	  (else #f)
	  ))))



(define (union-env env1_ env2_)
  (let ((env1 env1_)
	(env2 env2_))
    (if (do ((res #t (if (env1 'get (car todo)) #f #t))
	     (todo (dom-env env2) (cdr todo)))
	    ((or (null? todo) (not res)) res))
	(lambda args 
	  (let ((fun (aref args 0))
		(name (aref args 1))
		(expr (aref args 2)))
	    (case fun 
	      ('def
	       (if (eq? (env1 'get-def name) '�_np_�) 
		   (env2 'def name expr) #f))
	      
	      ('get 
	       (let ((e1 (env1 'get-def name))  
		     (e2 (env2 'get-def name)))
		 (if (eq? e1 '�_np_�) 
		     (if (eq? e2 '�_np_�) '�_np_� (e2 'value)) 
		     (e1 'value))))
	      
	       ('get-def 
		(let ((e1 (env1 'get-def name))  
		      (e2 (env2 'get-def name)))
		  (if (eq? e1 '�_np_�) e2 e1)))
	       
	       ('list (append (env1 'list) (env2 'list)))
	       ('storage (list (env1 'storage)  (env2 'storage))) 
	       (else #f)
	      )))
	#f)))

(define (get-env env name)
  (let ((res (env 'get name)))
    (if (eq? '�_np_� res)
	(plasm-exception `(,(symbol->string name) "No Such Function"))
	res)))

(define (get-name env name)
  (let ((res (env 'name name)))
    res))
