
; types
(define-struct anim-behaviour (configurations timeSteps))

; moved to Printer.scm
; (define-struct anim-pol-complex (pol id tStart tEnd))

(define (mk_id_gen)
  (let ((cnt 0))
    (lambda ()
      (begin
	(set! cnt (+ cnt 1))
	cnt))))

(define mk_move_id (mk_id_gen))

(define (anim_prop_VRMLanimation pol pre_port post_port)
  (let* ((curr_anim   (send pol get-prop-pol-complex  "VRMLanimation"))
	 (pre_string  (if (not (void? curr_anim)) 
			  (string-append (get-output-string pre_port) (car curr_anim))
			  (get-output-string pre_port)))
	 (post_string (if (not (void? curr_anim)) 
			  (string-append (cadr curr_anim) (get-output-string post_port))
			  (get-output-string post_port)))
	 (prop        `(,pre_string 
			,post_string))
	 (newpol (send pol
		       add-prop-pol-complex 
		       `("VRMLanimation" ,prop))))
    (add-gp newpol "VRMLanimation" prop)
    newpol))

(define (print-position port axis arg)
  (cond 
	 ; single tranlation 
   ((and (number? axis) (< axis 4) (> axis 0))				
    (case axis
      ((1) (fprintf port 
		    "~a 0 0" 
		    (exact->inexact arg)))
      ((2) (fprintf port 
		    "0 ~a 0" 
		    (exact->inexact arg)))
      ((3) (fprintf port 
		    "0 0 ~a" 
		    (exact->inexact arg)))))
   
	; multiple translation 
   ((and (pair? axis)  
	 (every (lambda (a) (and (< a 4) (> a 0))) axis))
    
    (do ((cnt 1  (+ cnt 1)))
	((> cnt 3))
      (fprintf port "~a "
	       (exact->inexact 
		(do ((todo arg (cdr todo))
		     (toaxis axis (cdr toaxis))
		     (res 0 (if (= cnt (car toaxis)) 
				(+ res (car todo))
				res)))
		    ((null? todo) res)
		  )))))
   (#t (plasm-exception `( "Plasm Animation: Animation of Transforms is allowed only on geometric dimensions (< 3)")))
	))

(define (print-scale-factor port axis arg)
  (cond 
	 ; single tranlation 
   ((and (number? axis) (< axis 4) (> axis 0))				
    (case axis
      ((1) (fprintf port 
		    "~a 1 1" 
		    (exact->inexact arg)))
      ((2) (fprintf port 
		    "1 ~a 1" 
		    (exact->inexact arg)))
      ((3) (fprintf port 
		    "1 1 ~a" 
		    (exact->inexact arg)))))
   
	; multiple translation 
   ((and (pair? axis)  
	 (every (lambda (a) (and (< a 4) (> a 0))) axis))
    
    (do ((cnt 1  (+ cnt 1)))
	((> cnt 3))
      (fprintf port "~a "
	       (exact->inexact 
		(do ((todo arg (cdr todo))
		     (toaxis axis (cdr toaxis))
		     (res 0 (if (= cnt (car toaxis)) 
				(+ res (car todo))
				res)))
		    ((null? todo) res)
		  )))))
   (#t (plasm-exception `( "Plasm Animation: Animation of Transforms is allowed only on geometric dimensions (< 3)")))
	))

(define (print-orientation port axis arg)
  (begin 
    (cond 
     ((equal? axis '(1 2)) (fprintf port "0 0 1 "))
     ((equal? axis '(2 1)) (fprintf port "0 0 -1 "))
     ((equal? axis '(1 3)) (fprintf port "0 -1 0 "))
     ((equal? axis '(3 1)) (fprintf port "0 1 0 "))
     ((equal? axis '(2 3)) (fprintf port "1 0 0 "))
     ((equal? axis '(3 2)) (fprintf port "-1 0 0 "))
     (#t (plasm-exception `( "Plasm Animation: Animation of Transforms is allowed only on geometric dimensions (< 3)"))))
    (fprintf port "~a" (exact->inexact arg))))
    

(define (anim-action what arg anim pol) 
  (let ((conf (anim-behaviour-configurations  anim))
	(t_steps (anim-behaviour-timeSteps anim))
	(pre_port (open-output-string))
	(post_port (open-output-string))
	(anim_id (mk_move_id)))
	
    
    ; Open new group and its children the routes of animation nodes must be outside these children 
    (fprintf pre_port "Group { children [ # START Plasm Animation of a ")
    (case what
      ('t (fprintf pre_port "Translation"))
      ('s (fprintf pre_port "Scale"))
      ('t (fprintf pre_port "Rotation")))
    (fprintf pre_port " (Animation Id=~a)" anim_id)
    (fprintf pre_port ", indentation temporarly suspended~%")
	         
    ; script
    (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" anim_id)
    (fprintf pre_port " eventIn  SFFloat set_time~%")
    (fprintf pre_port " eventOut SFFloat fraction_changed~%")
    (fprintf pre_port " url \"javascript: ~%")
    (fprintf pre_port "  function set_time(time, ts) {~%")
    (fprintf pre_port "       fraction_changed=time}\"}~%")
		   
    ; Interpolator
    ; name
    (fprintf pre_port "DEF PlasmAnimInterpol_~a " anim_id)
    ; interpolator type depending on type
    (case what
      ((t s) (fprintf pre_port "PositionInterpolator~%"))
      ('r (fprintf pre_port "OrientationInterpolator~%")))
    (fprintf pre_port "{~%")

    ; keys of interpolator
    ; key[i]= ti - t0 / tn - to
    ; keys = 0, ... , ti - t0 / tn - to, ... , 1 
    (let* ((len (length t_steps))
	   (t0 (car t_steps))
	   (tn (list-ref t_steps (- len 1) ))
	   (seg (- tn t0))
	   )
      
      (fprintf pre_port "key [ ")
      (do ((todo t_steps (cdr todo)))
	  ((null? todo))
	  (fprintf pre_port 
		   "~a~a" 
		   (exact->inexact (/ (- (car todo) t0) seg))
		   (if (null? (cdr todo)) " " ", ")
		   ))
      (fprintf pre_port " ]~%"))

    ;key values 
    (fprintf pre_port "keyValue [~%")
      ; for every configuration
    (do ((todo conf (cdr todo)))
	((null? todo))
      (begin
	(case what
	  ; depending on interpolator and value type
	  ('t (print-position pre_port arg (car todo)))
	  ('s (print-scale-factor pre_port arg (car todo)))
	  ('r (print-orientation pre_port arg (car todo))))
	(if (null? (cdr todo))
	    (fprintf pre_port "~%")
	    (fprintf pre_port ",~%"))))
    (fprintf pre_port "] }~%")
    
    
    ; Transform node to animate and its first value 
    (fprintf pre_port "DEF PlasmAnimTransf_~a Transform  {~%" anim_id)
    (case what
	    ; depending on transform and value type
      ('t 
       (fprintf pre_port "translation ") 
       (print-position pre_port arg (car conf)))
      ('s 
       (fprintf pre_port "scale ") 
       (print-scale-factor pre_port arg (car conf)))
      ('r 
       (fprintf pre_port "rotation ") 
       (print-orientation pre_port arg (car conf))))
    (fprintf pre_port "~%")

    ; children ..
    (fprintf pre_port "children [ # indentation resuming to previous position~%")
      
    ; After the node, the ROUTES 
    (fprintf post_port "] } ] # indentation temporarly suspended~%")
    (fprintf post_port 
	     "ROUTE PlasmAnimInterpol_~a.value_changed TO PlasmAnimTransf_~a." anim_id anim_id)
    (case what
	; depending on interpolator, transform and value type
      ('t (fprintf post_port "translation ~%"))
      ('s (fprintf post_port "scale ~%"))
      ('r (fprintf post_port "rotation ~%")))
    (fprintf post_port 
	     "ROUTE PlasmAnimTimerSwitch_~a.fraction_changed TO PlasmAnimInterpol_~a.set_fraction~%" anim_id anim_id)
    
    ; if child node is an animated pol complex, have to route that to the new TimerSwitch
    (if (anim-pol-complex? pol)
	(fprintf post_port 
	     "ROUTE PlasmAnimTimerSwitch_~a.fraction_changed TO PlasmAnimTimerSwitch_~a.set_time~%" 
	     anim_id 
	     (anim-pol-complex-id pol)))
    

    (fprintf post_port "} # END Plasm Animation of a ")
    (case what
		   ('t (fprintf post_port "Translation"))
		   ('s (fprintf post_port "Scale"))
		   ('t (fprintf post_port "Rotation")))
    (fprintf post_port " (Animation Id=~a)" anim_id)
    (fprintf post_port ", indentation resumed~%")
   
    ; if pol is animated, put the complex inside the new one
    (if (anim-pol-complex? pol)
	(set! pol (anim-pol-complex-pol pol)))

    ; now that the VRML strings are built attach them to the hierarchy
    (set! pol (anim_prop_VRMLanimation pol pre_port post_port))

    ; make the animated pol complex
    (make-anim-pol-complex pol anim_id 0 1)
    
    ))

; needs to be changed, this and the VRMLWriter
(define (anim-action-mkpol anim pols)
  (let* ((conf (anim-behaviour-configurations  anim))
	 (t_steps (anim-behaviour-timeSteps anim))
	 (keys_port (open-output-string))
	 (id_port (open-output-string))
	 (anim_id (mk_move_id))
	 (pre_port (open-output-string))
	 (post_port (open-output-string)))

    ; make resulting polc, protect children from reduction
    (fprintf pre_port "# MkPol/Map Anim do not reduce!!")
    (fprintf post_port "# MkPol/Map Anim do not reduce!!")
    (set! pols (struct-pol-complex (map (lambda (pol) (anim_prop_VRMLanimation pol pre_port post_port)) pols)))

    ; id for current interpolation
    (fprintf id_port "~a" anim_id)

    ; keys of interpolator
    ; key[i]= ti - t0 / tn - to
    ; keys = 0, ... , ti - t0 / tn - to, ... , 1 
    (let* ((len (length t_steps))
	   (t0 (car t_steps))
	   (tn (list-ref t_steps (- len 1) ))
	   (seg (- tn t0))
	   )
      (do ((todo t_steps (cdr todo)))
	  ((null? todo))
	(fprintf keys_port 
		 "~a~a" 
		 (exact->inexact (/ (- (car todo) t0) seg))
		 (if (null? (cdr todo)) " " ", ")
		 ))
      )

     ; now that the VRML strings are built attach them to the hierarchy
    (let* ((id_string (get-output-string id_port))
	   (keys_string (get-output-string keys_port))
	   (newpol (send pols
			 add-prop-pol-complex 
			 `("VRMLanimationmkpol" (,id_string 
						 ,keys_string)))))
      (add-gp newpol 
	    "VRMLanimation" `(,id_string
				,keys_string))
      (make-anim-pol-complex newpol anim_id 0 1))))

(define (anim-arg a)
  (let ((alen 0)
	(atime '()))
    (cond
; A single animation behaviour argument is itself
     ((anim-behaviour? a) a)
; a non-list is itself 
     ((not (pair? a)) a)
;a sequence where there are animation behaviour (or in a sub-sequence)
;becomes a anim behaviour of lists
;there is no check if more behaviours are compatible,
;this is because this should never happen
     ((do ((todo a (cdr todo))
	   (elem (anim-arg (car a)) (if (null? (cdr todo))
					'()
					(anim-arg (car (cdr todo))))))
	  ((or (null? todo) (anim-behaviour? elem))
	   (if (null? todo)
	       #f
	       (begin
		 (set! alen (length 
			     (anim-behaviour-configurations elem)))
		 (set! atime (anim-behaviour-timeSteps elem))
		 #t))))
      (do ((todo a (cdr todo))
	   (res '() (append 
		     res
		     (list (let ((elem (anim-arg (car todo))))
			     (if (anim-behaviour? elem)
				 (anim-behaviour-configurations elem)
				 (((get-env *env* '\#) alen) elem)))))))
	   ((null? todo)
	   (make-anim-behaviour 
	    ((get-env *env* 'TRANS) res)
	    atime
	    ))))
; everything else is itself (but not an animation behaviour)
     (#t a))))


(define (anim-pred pred arg)
  (every pred (anim-behaviour-configurations arg)))


;(define (Anim-Type Pred Exc Arg_)
;  (Let ((Arg (Anim-Arg Arg_)))
;    (If (Anim-Pred Pred Arg_) 
;	Arg
;	(Plasm-Exception Exc))))

(define (anim-apply 
	 fun)
  (lambda (arg_exc)
    (let ((arg (anim-arg (car arg_exc)))
	  (exc (cadr arg_exc)))
      (if (anim-behaviour? arg)
	  (make-anim-behaviour (map fun (anim-behaviour-configurations arg))
			       (anim-behaviour-timeSteps arg)
			       )
	  (plasm-exception exc)))))


;Move evaluates PLASM function in this environment
(define *anim-env* 
  (make-env make-val-def (make-hash-assoc)))

; for avaluatin compile time exps
(define *tmp_anim_env* *env*)
(set! *env* (add-env *anim-env* *env*))


; REDEFINITION OF FUNCTIONAL COMBINATORS for animation 

(for-each 

  ; *** For each:: function to apply ***
  (lambda (elem) 
    (if (pair? (car elem))
      (for-each (lambda (name) (*anim-env* 'def name (eval `(lambda () ,(cadr elem))))) (car elem))
      (*anim-env* 'def (car elem) (eval `(lambda () ,(cadr elem))))))
      

  
  ; *** For each::list ***
  
`(

  (apply (lambda (fun_and_arg)
      (if (and (pair? fun_and_arg)
	       (eq? 2 (length fun_and_arg))
	       (procedure? (car fun_and_arg)))
	  (((get-env *f_env* 'CATCH)
	    `(,(car fun_and_arg)
	      ,(anim-apply(car fun_and_arg) )))
	   (cadr fun_and_arg))
	  (plasm-exception `( "APPLY" "[|IsFun,IsVal|]" ,fun_and_arg)))))

  (cons (lambda (fun_list) 
	   (if (every procedure? fun_list)
	       (lambda (arg) 
		 (map (lambda (fun) ((get-env *env* 'APPLY) 
				     ((get-env *env* 'list) 
				      fun arg)))
		      fun_list))
	       (plasm-exception `( "CONS" "IsSeqOf:IsFun" ,fun_list)))))
  
  (pcons (lambda (fun_list) 
	    (if (every procedure? fun_list)
		(lambda (arg_list) 
		  (if (and (list? arg_list)
			   (= (length arg_list) (length fun_list)))
		      (do ((arg_list arg_list (cdr arg_list))
			   (fun_list fun_list (cdr fun_list))
			   (res '()))
			  ((null? arg_list) res)
			(set! res (append res (list 
					       ((get-env *env* 'APPLY) 
						((get-env *env* 'list) 
						 (car fun_list) (car arg_list))))
					       )))
		      (plasm-exception `( "PCONS:IsSeqOf:IsFun" "IsSeq (??)" ,arg_list))))
		(plasm-exception `( "PCONS" "IsSeqOf:IsFun" ,fun_list)))))
    
  (aa (lambda (fun) 
	 (if (procedure?  fun) 
	     (lambda (arg_list)
	       (if (list? arg_list)
		   (map (lambda (arg) ((get-env *env* 'APPLY) 
				       ((get-env *env* 'list) 
					fun arg)))
			arg_list)
		   (plasm-exception `( "AA:IsFun" "IsSeq" ,arg_list))))
	     (plasm-exception `( "AA" "IsFun" ,fun)))))

  (lift (lambda (fun) 
	   (if (procedure?  fun) 
	       (lambda (fun_list) 
		 (if  (every procedure? fun_list)
		      (lambda (arg)
			((get-env *env* 'APPLY) ((get-env *env* 'list) 
						 fun 
						 (map (lambda (fun) ((get-env *env* 'APPLY) 
								     ((get-env *env* 'list) 
								      fun arg)))
						      fun_list))))
		      (plasm-exception `( "LIFT:IsFun" "IsSeqOf:IsFun" ,fun_list))))
	       (plasm-exception `( "LIFT" "IsFun" ,fun)))))
  
  (raise (lambda (fun) 
	    (if (procedure?  fun) 
		(lambda (list) 
		  (cond ((and (pair? list) (every procedure? list))
			 (lambda (arg)
			   ((get-env *env* 'APPLY) ((get-env *env* 'list) 
						    fun 
						    (map (lambda (fun) ((get-env *env* 'APPLY) 
									((get-env *env* 'list) 
									 fun arg)))
							 list)))))
			(#t ((get-env *env* 'APPLY) ((get-env *env* 'list) fun list)))))	
		(plasm-exception `( "RAISE" "IsFun" ,fun)))))

  ; I don't understand why I have to re-define these ... however
  (+ ((get-env *env* 'APPLY) ((get-env *env* 'list) (get-env *env* 'raise) (get-env *env* 'add))))

  (- ((get-env *env* 'APPLY) ((get-env *env* 'list) (get-env *env* 'raise) (get-env *env* 'sub))))

  (* ((get-env *env* 'APPLY) ((get-env *env* 'list) (get-env *env* 'raise) (get-env *env* 'mul))))
  
  (** ((get-env *env* 'APPLY) ((get-env *env* 'list) (get-env *env* 'raise) (get-env *env* 'powerelev))))

  (/ ((get-env *env* 'APPLY) ((get-env *env* 'list) (get-env *env* 'raise) (get-env *env* 'div))))
  

  (c  (lambda (fun) 
	 (if (procedure?  fun)
	     (lambda (x) (lambda (y) 
			   ((get-env *env* 'APPLY) 
			    ((get-env *env* 'list) 
			     fun (list x y)))))
	     (plasm-exception `( "C" "IsFun" ,fun)))))

  (comp (lambda (fun_list) 
	  (if (every procedure? fun_list)
	      (lambda (arg) 
		(do ((res arg)
		     (todo (reverse fun_list) (cdr todo)))
		    ((null? todo) res)
		  (set! res 
			((get-env *env* 'APPLY) 
			 ((get-env *env* 'list) 
			   (car todo) res)))))
	      (plasm-exception `( "COMP" "IsSeqOf:IsFun" ,fun_list)))))
  
  (~ (lambda (fun_list) 
       (if (every procedure? fun_list)
	   (lambda (arg) 
	     (do ((res arg)
		  (todo (reverse fun_list) (cdr todo)))
		 ((null? todo) res)
	       (set! res ((get-env *env* 'APPLY) 
			  ((get-env *env* 'list) 
			   (car todo) res)) )))
	   (plasm-exception `( "COMP" "IsSeqOf:IsFun" ,fun_list)))))
  
  

  (if (lambda (fun_list)
	(if (and
	     (pair? fun_list)
	     (eq? 3 (length fun_list))
	     (every procedure? fun_list))
	    (lambda (arg)
	      (let* ((anim_arg (anim-arg arg))
		     (cond_res (if (anim-behaviour? anim_arg)
				   ; '() case to be considered 
				   (anim-pred (car fun_list) anim_arg) 
				   ((car fun_list) arg))))
		(if (and cond_res (not (eq? cond_res '())))
		    ((get-env *env* 'apply) 
		     ((get-env *env* 'list)
		      (cadr fun_list)
		      arg))
		    ((get-env *env* 'apply) 
		     ((get-env *env* 'list)
		      (caddr fun_list)
		      arg)))
		))
	    (plasm-exception `( "IF" "[|IsFun,IsFun,IsFun|]" ,fun_list)))))
  
  (insl (lambda (fun)
     (if (procedure? fun)
         (lambda (arg_list)
	   (if (pair? arg_list)
	       (do ((res (car arg_list) 
			 ((get-env *env* 'apply) 
			  ((get-env *env* 'list)
			   fun (list res (car todo)))))
		    (todo (cdr arg_list) (cdr todo)))
		   ((null? todo) res))
	       (plasm-exception `( "INSL:IsFun" "AND~[IsSeq,NOT~ISNULL]" ,arg_list))))
         (plasm-exception `( "INSL" "IsFun" ,fun)))))
  
  
  (insr (lambda (fun)
	   (if (procedure? fun)
	       (lambda (arg_list)
		 (if (pair? arg_list)
		     (do ((res (list-ref arg_list (1- (length arg_list)))
			       ((get-env *env* 'apply) 
				((get-env *env* 'list)
				 fun (list (car todo) res))))
			 (todo (cdr (reverse arg_list)) (cdr todo)))
			 ((null? todo) res))
		     (plasm-exception `( "INSR:IsFun" "AND~[IsSeq,NOT~ISNULL]" ,arg_list))))
	       (plasm-exception `( "INSR" "IsFun" ,fun)))))

  ; vedere plasm-orig, sospetto incoerenza tra plasm e  FL
  (tree (lambda (fun)
	   (if (procedure? fun)
	       (lambda (arg_list)
		 (if (pair? arg_list) 
		     (let tree ((fun fun)
				(arg_list arg_list))
		       (if (null? (cdr arg_list)) 
			   (car arg_list)
			   (let* ((n (length arg_list))
				 ;(k (ceiling (/ n 2)))
				  (k (quotient n 2))
				 ;(k (+ (quotient n 2) (remainder n 2)))
				  )
			     ((get-env *env* 'apply) 
			      ((get-env *env* 'list)
			       fun
			       ((get-env *env* 'list) 
				(tree fun (reverse! (list-tail (reverse arg_list) 
							       (- n k))))
				(tree fun (list-tail arg_list k))))))))
		     (plasm-exception 
		      `( "TREE:IsFun" "AND~[IsSeq,NOT~ISNULL]" ,arg_list))))
	       (plasm-exception `( "TREE" "IsFun" ,fun)))))
  
  ; to review, da rivedere
  (merge (lambda (fun)
	    (if (procedure? fun)
		(lambda (arg_list)
		  (if (and (pair? arg_list) (every list? arg_list))
		      (let merge ((fun fun)
				  (arg_list arg_list))
			(cond ((null? (car arg_list)) (cadr arg_list))
			      ((null? (cadr arg_list)) (car arg_list))
			      ((get-env *env* 'apply) 
			       ((get-env *env* 'list)
				fun (list (caar arg_list) (caadr arg_list))))
			       (cons (caar arg_list) 
				     (merge fun (list (cdar arg_list) (cadr arg_list))))
			      (#t (cons (caadr arg_list) 
					(merge fun (list (car arg_list) (cdadr arg_list)))))))  
		      (plasm-exception `( "MERGE:IsFun" "AND~[IsSeq,NOT~ISNULL]" ,arg_list))))
		(plasm-exception `( "MERGE" "IsFun" ,fun)))))

  ; to review, da rivedere
  (case (lambda (pred-funs) 
	   (if (and (list? pred-funs)
		    (every (lambda (elem) (and (list? elem) 
					       (eq? 2 (length elem))
					       (every procedure? elem))) pred-funs))
	       (lambda (arg)

		 (do (		
		      (pres 
		       ((get-env *env* 'APPLY) 
			((get-env *env* 'list) 
			 (caar pred-funs) arg))
		       ((get-env *env* 'APPLY) 
			((get-env *env* 'list) 
			 ((caar todo) arg))))
		      (todo pred-funs ))
		     ((or pres (null? todo)) 
		      (if (null? todo) 
			  (plasm-exception 
			   `( "CASE:(IsSeqOf:(AND~[IsPair,IsSeqOf:IsFun]):TT)" "Non Exaustive Predicates" ))
			  ((cadar todo) arg)))
		   (set! todo (cdr todo))))
	       

	       (plasm-exception 
		`( "CASE" "IsSeQOf:(AND~[IsPair,IsSeqOf:IsFun]" ,pred-funs)))))
  ))


  ; REDEFINITION OF GEOMETRIC PRIMITIVES
(for-each 
 (lambda (elem) 
    (if (pair? (car elem))
      (for-each (lambda (name) (*env* 'def name (eval `(lambda () ,(cadr elem))))) (car elem))
      (*anim-env* 'def (car elem) (eval `(lambda () ,(cadr elem))))))
 `(
   (t (lambda (axis) 
	(cond 
	 ((integer? axis) 
	  (lambda (args)
	    (if (and (anim-behaviour? args)
		     (anim-pred number? args))
		(lambda (pol)
		  (if (or (pol-complex? pol) (anim-pol-complex? pol))
		      (anim-action 'T axis args pol)
		      (plasm-exception `( "T:IsInt:IsNum" "IsPol /\\ IsAnimPol" ,pol))))
		(((get-env *tmp_anim_env* 't) axis) args))))	
	((and (pair? axis) (every  integer? axis))
	 (lambda (args) 
	   (let ((anim_args (anim-arg args)))
	     (if (and (anim-behaviour? anim_args)
		      (anim-pred (lambda (args)
				   (and (pair? args) 
					(every  number? args) 
					(eq? (length axis) (length args))))
				 anim_args))
		 (lambda (pol)
		   (if (or (pol-complex? pol) (anim-pol-complex? pol))
		       (anim-action 'T axis anim_args pol)
		       (plasm-exception `( "T:(IsSeqOf:IsInt):(IsSeqOf:IsNum)" "IsPol /\\ IsAnimPol" ,pol))))
		 (((get-env *tmp_anim_env* 't) axis) args)))))
	(#t ((get-env *tmp_anim_env* 't) axis)))))
   
   (s (lambda (axis) 
	(cond 
	 ((integer? axis) 
	  (lambda (args)
	    (if (and (anim-behaviour? args)
		     (anim-pred number? args))
		(lambda (pol)
		  (if (or (pol-complex? pol) (anim-pol-complex? pol))
		      (anim-action 'S axis args pol)
		      (plasm-exception `( "S:IsInt:IsNum" "IsPol /\\ IsAnimPol" ,pol))))
		(((get-env *tmp_anim_env* 's) axis) args))))	
	 ((and (pair? axis) (every  integer? axis))
	  (lambda (args) 
	    (let ((anim_args (anim-arg args)))
	      (if (and (anim-behaviour? anim_args)
		       (anim-pred (lambda (args)
				    (and (pair? args) 
					 (every  number? args) 
					 (eq? (length axis) (length args))))
				  anim_args))
		  (lambda (pol)
		    (if (or (pol-complex? pol) (anim-pol-complex? pol))
			(anim-action 'S axis anim_args pol)
			(plasm-exception `( "S:(IsSeqOf:IsInt):(IsSeqOf:IsNum)" "IsPol /\\ IsAnimPol" ,pol))))
		  (((get-env *tmp_anim_env* 's) axis) args)))))
	 (#t ((get-env *tmp_anim_env* 's) axis)))))
   
   (r (lambda (axis) 
	(cond 
	 ((and (pair? axis) 
	       (every  integer? axis) 
	       (eq? 2 (length  axis)))
	  (lambda (args)
	    (if (and (anim-behaviour? args)
		     (anim-pred number? args))
		(lambda (pol)
		  (if (or (pol-complex? pol) (anim-pol-complex? pol))
		      (anim-action 'R axis args pol)
		      (plasm-exception `( "R:IsInt:IsNum" "IsPol /\\ IsAnimPol" ,pol))))
		 (((get-env *tmp_anim_env* 'r) axis) args))))
	 ((and (pair? axis) 
	       (every (lambda (ax) (and (pair? ax)
					(every  integer? ax)
					(eq? 2 (length  ax))))
		      axis))
            (lambda (args)
		  (let ((anim_args (anim-arg args)))
		    (if (and (anim-behaviour? anim_args)
			     (anim-pred (lambda (args)
					  (and (pair? args) 
					       (every  number? args) 
					       (eq? (length axis) (length args))))
					anim_args))
			(lambda (pol)
			  (if (or 
			    (pol-complex? pol) (anim-pol-complex? pol))
			      (let ((res (if (anim-pol-complex? pol)
					     (anim-pol-complex-pol pol)
					     pol)))
				(for-each (lambda (ax arg)
					    (set! res (anim-action 'R `(,(car ax) ,(cadr ax)) arg res)))
					  axis args)
				(if (anim-pol-complex? pol)
				    (make-anim-pol-complex res
							   (anim-pol-complex-id pol)
							   (anim-pol-complex-tStart pol)
							   (anim-pol-complex-tEnd pol))
				    res))
			    (plasm-exception `( "T:(IsSeqOf:IsInt):(IsSeqOf:IsNum)" "IsPol /\\ IsAnimPol" ,pol))))
			(((get-env *tmp_anim_env* 'r) axis ) args)))))
           (#t ((get-env *tmp_anim_env* 'r) axis)))))


  (cuboid (lambda (dims)
	    (if (and (list? dims) (every number? dims))
		(do ((res (build-pol-complex-cube (length dims))
			  (send res scale-pol-complex cnt (exact->inexact (aref dims cnt))))
		     (cnt 0 (1+ cnt)))
		    ((>= cnt (length dims)) res))
		(let ((anim_args (anim-arg dims)))
		  (if (and (anim-behaviour? anim_args)
			   (anim-pred (lambda (args)
					(and (list? args) (every number? args)))
				      anim_args))
		      (let* ((conf (anim-behaviour-configurations anim_args))
			     (len (length (car conf)))
			     (axis (do ((cnt len (- cnt 1))
					(res '() (cons cnt res)))
				       ((= cnt 0) res)))
			     (cube (build-pol-complex-cube len)))
			(anim-action 'S axis anim_args cube))
		      (plasm-exception `( "CUBOID" "IsSeqOf:IsNum" ,dims)))))))
			    
  (mkpol (lambda (three_seq)
	   (if (and (pair? three_seq)
		    (= 3 (length three_seq))
		    (pair? (cadr three_seq))
		    (pair? (caddr three_seq))
		    (every (lambda (cell)
			     (and (pair? cell)
				  (every integer? cell)))
			   (cadr three_seq))
		    (every (lambda (pol) 
			     (and (pair? pol)
				  (every integer? pol)))
			   (caddr three_seq)))
	       ; normal struct 
	       (if (every (lambda (point) 
			    (and (pair? point)
				 (= (length (car (car three_seq))) 
				    (length point))
				 (every number? point)))
			  (car three_seq))
		   (apply make-pol (list 
				    (map (lambda (seq)
					   (map exact->inexact seq))
					 (car three_seq))
				    (cadr three_seq) (caddr three_seq)))
					; normal animation
		   (let ((anim_points (anim-arg (car three_seq))))
		     (if (and (anim-behaviour? anim_points)
			      (anim-pred (lambda (a)
					   (every 
					    (lambda (point) 
					      (and (pair? point)
						   (= (length (car (car (anim-behaviour-configurations anim_points))))
						      (length point))
						   (every number? point)))
					    a))
					   anim_points))
			 
			 (anim-action-mkpol 
			  anim_points   
			  (map (lambda (a)
				 (apply make-pol 
					(list 
					 (map (lambda (seq)
						(map exact->inexact seq))
					      a)
					 (cadr three_seq) 
					 (caddr three_seq))))
			       (anim-behaviour-configurations anim_points))
 			    )
			   (plasm-exception `( "MkPol" "[|IsSeqOf:((IsSeqOf:IsNum) /\\ (?)),IsSeqOf:((IsSeqOf:IsInt),IsSeqOf:((IsSeqOf:IsInt)|]" ,three_seq)))))
	       (plasm-exception `( "MkPol" "[|IsSeqOf:((IsSeqOf:IsNum) /\\ (?)),IsSeqOf:((IsSeqOf:IsInt),IsSeqOf:((IsSeqOf:IsInt)|]" ,three_seq)))))
  
  
  (cmap (lambda (afun) 
   (if (procedure? afun)      
       (lambda (apol)
         (if (pol-complex? apol)
	     (let* (
		    (back_anim '())
		    (is_anim #f)
		    (which 0)
		    (anew_fun 
		     (lambda (arg)
		       (let ((anim_res (anim-arg (afun arg))))
			 (if (anim-behaviour? anim_res)
			     (begin
			       (set! is_anim #t)
			       (set! back_anim anim_res)
			       (if (= (length (anim-behaviour-configurations anim_res))
				     (+ which 1))
				   (set! is_anim #f))
			       (aref (anim-behaviour-configurations anim_res) which))
			     anim_res)
			 )))
		    (ares (send apol map-pol-complex2 anew_fun)))
	       (if is_anim
		   (do ((res `(,ares) (append res 
					      (list 
					       (send apol map-pol-complex2 anew_fun)))))
		       ((not is_anim) (anim-action-mkpol back_anim res))
		     (set! which (+ which 1)))
		   ares))
	     (plasm-exception `( "CMAP:IsFun" "IsPol" ,apol))))
       (plasm-exception `( "CMAP" "IsFun" ,afun)))))

  ; protect animation function in move
  (move (lambda (a) (plasm-exception `( "MOVE" "Not allowed in move"))))

  (frame (lambda (a) (plasm-exception `( "FRAME" "Not allowed in move"))))

  (animatione (lambda (a) (plasm-exception `( "ANIMATION" "Not allowed in move"))))

  (loop (lambda (a) (plasm-exception `( "LOOP" "Not allowed in move"))))

  (innerloop (lambda (a) (plasm-exception `( "INNERLOOP" "Not allowed in move"))))

  (shift (lambda (a) (plasm-exception `( "SHIFT" "Not allowed in move"))))

  (warp (lambda (a) (plasm-exception `( "WARP" "Not allowed in move"))))

  ))

; now normal environment
(set! *env* *tmp_anim_env*)


(define (anim-frame pols time-behaviour)
  (let* ((pre_port (open-output-string))
	 (post_port (open-output-string))
	 (pre_port_tmp (open-output-string))
	 (post_port_tmp (open-output-string))
	 (move_id (mk_move_id))
	 (len (length time-behaviour))
	 (t0 (exact->inexact(car time-behaviour)))
	 (tn (exact->inexact (list-ref time-behaviour (- len 1) ))))

    ; make resulting polc, protect children from reduction
    (fprintf pre_port_tmp "# MkPol/Map Anim do not reduce!!")
    (fprintf post_port_tmp "# MkPol/Map Anim do not reduce!!")
    (set! pols (struct-pol-complex (map (lambda (pol) (anim_prop_VRMLanimation pol pre_port post_port)) pols)))

    (fprintf pre_port "Group { children [ # START Plasm Animation of a FRAME")
    (fprintf pre_port " (M=~a)" move_id)
    (fprintf pre_port ", indentation temporarly suspended~%")
    (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" move_id)
    (fprintf pre_port "eventIn  SFFloat set_time~%")
    (fprintf pre_port "eventOut SFInt32 whichChoice~%")
    (fprintf pre_port "url \"javascript: ~%")
    (fprintf pre_port "function set_time(time, ts) {~%")
    (fprintf pre_port "if(time<~a) whichChoice=-1;~%" t0)
    (do ((cnt 1 (+ cnt 1)))
	((= cnt (- len 1)))	 
      (fprintf pre_port "if(time>=~a && time<=~a) whichChoice=~a;~%" 
	       (list-ref time-behaviour (- cnt 1)) 
	       (list-ref time-behaviour cnt)
	       (- cnt 1)))
    (if (>= tn 0)
	(begin
	  (fprintf pre_port "if(time>=~a && time<=~a) whichChoice=~a;~%" 
		   (list-ref time-behaviour (- len 2))
		   tn
		   (- len 2))
	  (fprintf pre_port "if(time>~a) whichChoice=-1;}\"}~%" tn))
	(fprintf pre_port "if(time>=~a) whichChoice=~a;}\"}~%" 
		 (list-ref time-behaviour (- len 2))
		 (- len 2)))

    (fprintf pre_port "DEF PlasmAnimSwitch_~a Switch {~%" move_id)
    (fprintf pre_port "choice [ # indentation resumed at previous position~%")

    (fprintf post_port " ] # indentation temporarly suspended~%")
    (fprintf post_port "whichChoice -1 } ~%")
    (fprintf post_port "]~%")
    (fprintf post_port 
	     "ROUTE PlasmAnimTimerSwitch_~a.whichChoice TO PlasmAnimSwitch_~a.whichChoice~%"
	     move_id 
	     move_id)
    (fprintf post_port "} # END Plasm Animation of a FRAME")
    (fprintf post_port " (M=~a)" move_id)
    (fprintf post_port ", indentation resumed at previous position~%")
	     
    ; now that the VRML strings are built attach them to the hierarchy
    (set! pols (anim_prop_VRMLanimation pols pre_port post_port))
    
    ; make the resulting animated pol complex
    (make-anim-pol-complex (struct-pol-complex (list pols)) move_id  t0 tn)))
  
  

; scheme implementation of move
(define (anim-move fun configurations time-behaviour)
    (let* ((pre_port (open-output-string))
	   (post_port (open-output-string))
	   (move_id (mk_move_id))
	   (len (length time-behaviour))
	   (t0 (exact->inexact (car time-behaviour)))
	   (tn (exact->inexact(list-ref time-behaviour (- len 1) )))
	   (seg (- tn t0))
	   (res (fluid-let 
		    ((*env* (add-env *anim-env* *env*)))
		  (fun (make-anim-behaviour 
			configurations 
			time-behaviour)))))
      
      (cond ((and (anim-pol-complex? res)
		  (= (anim-pol-complex-tStart res) 0)
		  (= (anim-pol-complex-tEnd res) 1))
	     (fprintf pre_port "Group { children [ # START Plasm Animation of a MOVE")
	     (fprintf pre_port " (M=~a)" move_id)
	     (fprintf pre_port ", indentation temporarly suspended~%")
	     (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" move_id)
	     (fprintf pre_port "eventIn  SFFloat set_time~%")
	     (fprintf pre_port "eventOut SFInt32 whichChoice~%")
	     (fprintf pre_port "eventOut SFFloat time_changed~%")
	     (fprintf pre_port "url \"javascript: ~%")
	     (fprintf pre_port "function set_time(time, ts) {~%")
	     (fprintf pre_port "if(time<~a) whichChoice=-1;~%" t0)
	     (fprintf pre_port "if(time>=~a && time<=~a) whichChoice=0;~%" t0 tn)
	     (fprintf pre_port "if(time>~a) whichChoice=-1; ~%" tn) 
	     (fprintf pre_port "time_changed=(( time- ~a ) / ~a )}\"}~%" t0 seg)
	     (fprintf pre_port "DEF PlasmAnimSwitch_~a Switch {~%" move_id)
	     (fprintf pre_port "choice [~%")
	     (fprintf pre_port "Group { children [ # indentation resumed at previous position~%")

	     (fprintf post_port "] } ] # indentation temporarly suspended~%")
	     (fprintf post_port "whichChoice -1 } ~%")
	     (fprintf post_port "]~%")
	     (fprintf post_port 
			  "ROUTE PlasmAnimTimerSwitch_~a.whichChoice TO PlasmAnimSwitch_~a.whichChoice~%"
			  move_id 
			  move_id)
	     (fprintf post_port 
		      "ROUTE PlasmAnimTimerSwitch_~a.time_changed TO PlasmAnimTimerSwitch_~a.set_time~%" 
		      move_id 
		      (anim-pol-complex-id res))
	     (fprintf post_port "} # END Plasm Animation of a MOVE")
	     (fprintf post_port " (M=~a)" move_id)
	     (fprintf post_port ", indentation resumed at previous position~%")
	     
	     ; now that the VRML strings are built attach them to the hierarchy
	     (set! res (anim_prop_VRMLanimation (anim-pol-complex-pol res) pre_port post_port))

	     ; make the animated pol complex
	     (make-anim-pol-complex (struct-pol-complex (list res)) move_id  t0 tn)) 

	    
	    (#t (plasm-exception `
		 ( "Plasm Animation: The evaluation of the move didn't result in an animated pol-complex"))))))
      
(define (anim-struct-pol-complex pols)
  (let ((pre_port (open-output-string))
	(post_port (open-output-string))
	(anim_id (mk_move_id))
	(tStart -1)
	(tEnd -1)
	(ids '()))

    (set! pols
	  (map (lambda (elem)
		 (cond ((pol-complex? elem)
			elem)
		       ((anim-pol-complex? elem)
			(begin
			  (set! tStart (if (or (= tStart -1) (< (anim-pol-complex-tStart elem) tStart))
					   (anim-pol-complex-tStart elem)
					   tStart))
			  (set! tEnd (if (or (= tEnd -1) (> (anim-pol-complex-tEnd elem) tEnd))
					 (anim-pol-complex-tEnd elem)
					 tEnd))
			  
					; animation id make conflict in struct, make a new one
			  (let ((pre_port (open-output-string))
				(post_port (open-output-string))
				(tStart (anim-pol-complex-tStart elem))
				(tEnd (anim-pol-complex-tEnd elem))
				(anim_id (mk_move_id)))
					; make a new timerSwitch and route from this the duplicate animation
			    (fprintf pre_port "Group { children [ # START Plasm Animation RENAME")
			    (fprintf pre_port "of (Animation Id=~a)" (anim-pol-complex-id elem))
			    (fprintf pre_port "to (Animation Id=~a)" anim_id)
			    (fprintf pre_port "# indentation temporarly suspended~%")
					; script
			    (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" anim_id)
			    (fprintf pre_port " eventIn  SFFloat set_time~%")
			    (fprintf pre_port " eventOut SFFloat time_changed~%")
			    (fprintf pre_port " url \"javascript: ~%")
			    (fprintf pre_port "  function set_time(time, ts) {~%")
			    (fprintf pre_port "      time_changed=time}\"}~%")
			    (fprintf pre_port "# indentation resuming to previous position~%")
			    
					; route
			    (fprintf post_port "] # indentation temporarly suspended~%")
			    (fprintf post_port 
				     "ROUTE PlasmAnimTimerSwitch_~a.time_changed TO PlasmAnimTimerSwitch_~a.set_time~%" 
				     anim_id
				     (anim-pol-complex-id elem))
			    (fprintf post_port "} # END Plasm Animation of a RENAME (Animation ID=~a) # indentation resuming to previous position~%" anim_id)
					; collect new id
			    (set! ids (cons anim_id ids))
					;attach property make new anim-pol-complex
			    (set! elem (anim_prop_VRMLanimation (anim-pol-complex-pol elem) pre_port post_port))
			    elem)))))
	       pols))

    (set! pols (struct-pol-complex pols))

    (if (null? ids) 
        ;no animations inside this struct
	pols
        ; otherwise make new animation ...
	(begin
	  (fprintf pre_port "Group { children [ # START Plasm Animation of a STRUCT")
	  (fprintf pre_port " (Animation Id=~a)" anim_id)
	  (fprintf pre_port "# indentation temporarly suspended~%")
	  (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" anim_id)
	  (fprintf pre_port " eventIn  SFFloat set_time~%")
	  (fprintf pre_port " eventOut SFFloat time_changed~%")
	  (fprintf pre_port " url \"javascript: ~%")
	  (fprintf pre_port "  function set_time(time, ts) {~%")
	  (fprintf pre_port "      time_changed=time}\"}~%")
	  (fprintf pre_port "# indentation resuming to previous position~%")
	
	  (fprintf post_port "] # indentation temporarly suspended~%")
	  (for-each (lambda (id)
		      (fprintf post_port 
			       "ROUTE PlasmAnimTimerSwitch_~a.time_changed TO PlasmAnimTimerSwitch_~a.set_time~%" 
			       anim_id
			       id))
		    ids)
	  (fprintf post_port "} # END Plasm Animation of a STRUCT (Animation ID=~a)~%" anim_id)

	  (set! pols (make-anim-pol-complex (struct-pol-complex (list (anim_prop_VRMLanimation pols pre_port post_port)))
					    anim_id
					    tStart
					    tEnd))
	  pols))))
	  
		
(define (anim-loop inner times anim)
  (let* ((tStartOld (anim-pol-complex-tStart anim))
	 (tEndOld (anim-pol-complex-tEnd anim))
	 (idOld (anim-pol-complex-id anim))
	 (tStart tStartOld)
	 (tEnd (if inner 
		   (+ tStartOld (* times (- tEndOld tStartOld)))
		   (* times tEndOld)))
	 (period (if inner
		     (- tEndOld tStartOld)
		     tEndOld))
	 (anim_id (mk_move_id))
	 (pre_port (open-output-string))
	 (post_port (open-output-string)))

    (fprintf pre_port "Group { children [ # START Plasm Animation of a LOOP")
    (fprintf pre_port " (M=~a)" anim_id)
    (fprintf pre_port ", indentation temporarly suspended~%")
    (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" anim_id)
    (fprintf pre_port "eventIn  SFFloat set_time~%")
    (fprintf pre_port "eventOut SFFloat time_changed~%")
    (fprintf pre_port "eventOut SFInt32 whichChoice~%")
    (fprintf pre_port "url \"javascript: ~%")
    (fprintf pre_port "function set_time(time, ts) {~%")
    (fprintf pre_port "if(time<~a) whichChoice=-1;~%" tStart)
    (fprintf pre_port "if(time>=~a && time<=~a) whichChoice=0;~%" tStart tEnd)
    (fprintf pre_port "if(time>~a) whichChoice=-1; ~%" tEnd) 
    (if inner
	  (fprintf pre_port "time_changed=~a + ( ( time - ~a ) % ~a )}\"}~%" tStart tStart period)
	  (fprintf pre_port "time_changed=(time%~a)}\"}~%" period))
    (fprintf pre_port "DEF PlasmAnimSwitch_~a Switch {~%" anim_id)
    (fprintf pre_port "choice [~%")
    (fprintf pre_port "Group { children [ # indentation resumed at previous position~%")

    (fprintf post_port "] } ] # indentation temporarly suspended~%")
    (fprintf post_port "whichChoice -1 } ~%")
    (fprintf post_port "]~%")
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch_~a.time_changed  TO PlasmAnimTimerSwitch_~a.set_time~%" anim_id idOld)
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch_~a.whichChoice TO PlasmAnimSwitch_~a.whichChoice~%"
	     anim_id 
	     anim_id)
    (fprintf post_port "} # END Plasm animation of a LOOP, indentation  resumed at previous position~%")

    (set! anim (anim_prop_VRMLanimation (anim-pol-complex-pol anim) pre_port post_port))
    (set! anim (make-anim-pol-complex (struct-pol-complex (list anim)) anim_id tStart tEnd))
    anim
    ))

(define (anim-warp inner times anim)
  (let* ((tStartOld (anim-pol-complex-tStart anim))
	 (tEndOld (anim-pol-complex-tEnd anim))
	 (idOld (anim-pol-complex-id anim))
	 (tStart (if inner 
		     tStartOld
		     (abs (* times tStartOld))))
	 (tEnd (if inner
		   (+ tStartOld (abs (* times (- tEndOld tStartOld))))
		   (abs (* times (- tEndOld tStartOld)))))
	 (anim_id (mk_move_id))
	 (pre_port (open-output-string))
	 (post_port (open-output-string)))

    (fprintf pre_port "Group { children [ # START Plasm Animation of a WARP")
    (fprintf pre_port " (M=~a)" anim_id)
    (fprintf pre_port ", indentation temporarly suspended~%")
    (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" anim_id)
    (fprintf pre_port "eventIn  SFFloat set_time~%")
    (fprintf pre_port "eventOut SFFloat time_changed~%")
    (fprintf pre_port "eventOut SFInt32 whichChoice~%")
    (fprintf pre_port "url \"javascript: ~%")
    (fprintf pre_port "function set_time(time, ts) {~%")
    (fprintf pre_port "if(time<~a) whichChoice=-1;~%" tStart)
    (fprintf pre_port "if(time>=~a && time<=~a) whichChoice=0;~%" tStart tEnd)
    (fprintf pre_port "if(time>~a) whichChoice=-1; ~%" tEnd) 
    (if inner
	(if (> times 0)
	    (fprintf pre_port "time_changed=~a + ( ( time - ~a)  / ~a)}\"}~%" tStartOld tStart times)
	    (fprintf pre_port "time_changed=~a + ( ( time - ~a)  / ~a)}\"}~%" tEndOld tStart times))
	(if (> times 0)
	    (fprintf pre_port "time_changed=(~a (time / ~a))}\"}~%" (if (< times 0) "-" "" ) times)
	    (fprintf pre_port "time_changed=~a - (~a (time / ~a))}\"}~%" tEndOld (if (< times 0) "-" "" ) times)))
    (fprintf pre_port "DEF PlasmAnimSwitch_~a Switch {~%" anim_id)
    (fprintf pre_port "choice [~%")
    (fprintf pre_port "Group { children [ # indentation resumed at previous position~%")

    (fprintf post_port "] } ] # indentation temporarly suspended~%")
    (fprintf post_port "whichChoice -1 } ~%")
    (fprintf post_port "]~%")
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch_~a.time_changed  TO PlasmAnimTimerSwitch_~a.set_time~%" anim_id idOld)
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch_~a.whichChoice TO PlasmAnimSwitch_~a.whichChoice~%"
	     anim_id 
	     anim_id)
    (fprintf post_port "} # END Plasm animation of a WARP, indentation  resumed at previous position~%")

    (set! anim (anim_prop_VRMLanimation (anim-pol-complex-pol anim) pre_port post_port))
    (set! anim (make-anim-pol-complex (struct-pol-complex (list anim)) anim_id tStart tEnd))
    anim
    ))


(define (anim-shift t anim)
  (let* ((tStartOld (anim-pol-complex-tStart anim))
	 (tEndOld (anim-pol-complex-tEnd anim))
	 (idOld (anim-pol-complex-id anim))
	 (tStart (+ tStartOld t))
	 (tEnd (+ tEndOld t))
	 (anim_id (mk_move_id))
	 (pre_port (open-output-string))
	 (post_port (open-output-string)))

    (fprintf pre_port "Group { children [ # START Plasm Animation of a SHIFT")
    (fprintf pre_port " (M=~a)" anim_id)
    (fprintf pre_port ", indentation temporarly suspended~%")
    (fprintf pre_port "DEF PlasmAnimTimerSwitch_~a Script {~%" anim_id)
    (fprintf pre_port "eventIn  SFFloat set_time~%")
    (fprintf pre_port "eventOut SFFloat time_changed~%")
    (fprintf pre_port "eventOut SFInt32 whichChoice~%")
    (fprintf pre_port "url \"javascript: ~%")
    (fprintf pre_port "function set_time(time, ts) {~%")
    (fprintf pre_port "if(time<~a) whichChoice=-1;~%" tStart)
    (fprintf pre_port "if(time>=~a && time<=~a) whichChoice=0;~%" tStart tEnd)
    (fprintf pre_port "if(time>~a) whichChoice=-1; ~%" tEnd) 
    (fprintf pre_port "time_changed=time - ~a}\"}~%" t)
    (fprintf pre_port "DEF PlasmAnimSwitch_~a Switch {~%" anim_id)
    (fprintf pre_port "choice [~%")
    (fprintf pre_port "Group { children [ # indentation resumed at previous position~%")

    (fprintf post_port "] } ] # indentation temporarly suspended~%")
    (fprintf post_port "whichChoice -1 } ~%")
    (fprintf post_port "]~%")
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch_~a.time_changed  TO PlasmAnimTimerSwitch_~a.set_time~%" anim_id idOld)
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch_~a.whichChoice TO PlasmAnimSwitch_~a.whichChoice~%"
	     anim_id 
	     anim_id)
    (fprintf post_port "} # END Plasm animation of a SHIFT, indentation  resumed at previous position~%")

    (set! anim (anim_prop_VRMLanimation (anim-pol-complex-pol anim) pre_port post_port))
    (set! anim (make-anim-pol-complex (struct-pol-complex (list anim)) anim_id tStart tEnd))
    anim
    ))

(define (anim-pre-export anim)
  (let ((tStart (anim-pol-complex-tStart anim))
	(tEnd (anim-pol-complex-tEnd anim))
	(id (anim-pol-complex-id anim))
	(pre_port (open-output-string))
	(post_port (open-output-string)))

    (fprintf pre_port "Group { children [ # START Plasm ANIMATION, indentation temporarly suspended~%")
    (fprintf pre_port "DEF PlasmAnimTimer TimeSensor { cycleInterval ~a }~%" tEnd)
    (fprintf pre_port "DEF PlasmAnimTimerSwitch Script {~%")
    (fprintf pre_port " eventIn SFFloat set_fraction~%")
    (fprintf pre_port " eventOut SFFloat time_changed ~%")
    (fprintf pre_port " eventIn  SFBool isActive~%")
    (fprintf pre_port " eventOut SFInt32 whichChoice~%")
    (fprintf pre_port " url \"javascript: ~%")
    (fprintf pre_port "      function isActive(active, ts) {~%")
    (fprintf pre_port "         if (active) whichChoice=-1; else whichChoice=0;}~%")
    (fprintf pre_port "      function set_fraction(fraction, ts) {~%")
    (fprintf pre_port "         time_changed=fraction*~a;}\"}~%" tEnd)
    (fprintf pre_port "DEF PlasmAnimSwitch Switch { ~%")
    (fprintf pre_port " choice [~%")
    (fprintf pre_port "           DEF controlGlobalTransXY Transform  {~%")
    (fprintf pre_port "            rotation 1 0 0 1.570796326794895~%")
    (fprintf pre_port "            children [~%")
    (fprintf pre_port "            DEF controlGlobalTransXZ Transform {~%")
    (fprintf pre_port "             rotation 0 1 0 1.570796326794895~%")
    (fprintf pre_port "             children [~%")
    (fprintf pre_port "              DEF controlGlobalTransYZ Transform {~%")
    (fprintf pre_port "               rotation 0 -1 0 1.570796326794895~%")
    (fprintf pre_port "               children [~%")
    (fprintf pre_port "                Transform {~%")
    (fprintf pre_port "                 rotation -1 0 0 1.570796326794895~%")
    (fprintf pre_port "                 children [~%")
    (fprintf pre_port "                  Group { children [~%")
    (fprintf pre_port "                    DEF controlPosTransSensorXY PlaneSensor {}~%")
    (fprintf pre_port "                    DEF controlPlane Shape {~%")
    (fprintf pre_port "                     appearance Appearance {~%")
    (fprintf pre_port "                      material Material {~%")
    (fprintf pre_port "                       diffuseColor 0.8 0.8 0.8~%")
    (fprintf pre_port "                       ambientIntensity 1~%")
    (fprintf pre_port "                       specularColor 0.8 0.8 0.8~%")
    (fprintf pre_port "                       shininess 1~%")
    (fprintf pre_port "                       transparency 0.5~% } }")
    (fprintf pre_port "                     geometry IndexedFaceSet {~%")
    (fprintf pre_port "                      coord Coordinate { point [0 0 0, 1 0 0, 1 1 0, 0 1 0] }~%")
    (fprintf pre_port "                      coordIndex        [0, 1, 2, 3, -1, 3, 2, 1, 0, -1] } }~%")
    (fprintf pre_port "                    Transform {~%")
    (fprintf pre_port "                     rotation 1 0 0 1.570796326794895~%")
    (fprintf pre_port "                     children [~%")
    (fprintf pre_port "                      DEF controlPosTransSensorXZ PlaneSensor {}~%")
    (fprintf pre_port "                      USE controlPlane ~%")
    (fprintf pre_port "                      Transform {~%")
    (fprintf pre_port "                       rotation 0 1 0 1.570796326794895~%")
    (fprintf pre_port "                       children [~%")
    (fprintf pre_port "                        DEF controlPosTransSensorYZ PlaneSensor {}~%")
    (fprintf pre_port "                        USE controlPlane ] } ] } ] }~%")
    (fprintf pre_port "                  Shape {~%")
    (fprintf pre_port "                   appearance Appearance {~%")
    (fprintf pre_port "                    material Material {~%")
    (fprintf pre_port "                     diffuseColor 0 0 0~%")
    (fprintf pre_port "                     ambientIntensity 1~%")
    (fprintf pre_port "                     specularColor 0 0 0~%")
    (fprintf pre_port "                     emissiveColor 0 0 0~%")
    (fprintf pre_port "                     shininess 1~%")
    (fprintf pre_port "                     transparency 0 }}~%")
    (fprintf pre_port "                   geometry IndexedLineSet { ~%")
    (fprintf pre_port "                    coord Coordinate { point [0 0 0, 1 0 0, 0 1 0, 0 0 1] }~%")
    (fprintf pre_port "                    coordIndex        [0, 1, -1, 0, 2, -1, 0, 3, -1] } }~%")
    (fprintf pre_port "                  Transform  { ~%")
    (fprintf pre_port "                   translation      0.8 -0.2 0  ~%")
    (fprintf pre_port "                   scale 0.25 0.25 0.25~%")
    (fprintf pre_port "                   children [~%")
    (fprintf pre_port "                    Shape {~%")
    (fprintf pre_port "                     appearance Appearance {~%")
    (fprintf pre_port "                      material Material {~%")
    (fprintf pre_port "                       diffuseColor 0 0 0~%")
    (fprintf pre_port "                       ambientIntensity 1~%")
    (fprintf pre_port "                       specularColor 0 0 0~%")
    (fprintf pre_port "                       emissiveColor 0 0 0~%")
    (fprintf pre_port "                       shininess 1~%")
    (fprintf pre_port "                       transparency 0 } }~%")
    (fprintf pre_port "                      geometry Text { ~%")
    (fprintf pre_port "                       string [\"X\"] } } ] }~%")
    (fprintf pre_port "                  Transform  {~%")
    (fprintf pre_port "                   translation      -0.2 0.8 0~%")
    (fprintf pre_port "                   scale 0.25 0.25 0.25~%")
    (fprintf pre_port "                   children [~%")
    (fprintf pre_port "                    Shape {~%")
    (fprintf pre_port "                     appearance Appearance {~%")
    (fprintf pre_port "                      material Material {~%")
    (fprintf pre_port "                       diffuseColor 0 0 0~%")
    (fprintf pre_port "                       ambientIntensity 1~%")
    (fprintf pre_port "                       specularColor 0 0 0~%")
    (fprintf pre_port "                       emissiveColor 0 0 0~%")
    (fprintf pre_port "                       shininess 1~%")
    (fprintf pre_port "                       transparency 0 } }~%")
    (fprintf pre_port "                     geometry Text { ~%")
    (fprintf pre_port "                      string [\"Y\"] } } ] }~%")
    (fprintf pre_port "                  Transform  { ~%")
    (fprintf pre_port "                   translation      -0.2 -0.2 1  ~%")
    (fprintf pre_port "                   scale 0.25 0.25 0.25~%")
    (fprintf pre_port "                   children [~%")
    (fprintf pre_port "                    Shape {~%")
    (fprintf pre_port "                     appearance Appearance {~%")
    (fprintf pre_port "                      material Material {~%")
    (fprintf pre_port "                       diffuseColor 0 0 0~%")
    (fprintf pre_port "                       ambientIntensity 1~%")
    (fprintf pre_port "                       specularColor 0 0 0~%")
    (fprintf pre_port "                       emissiveColor 0 0 0~%")
    (fprintf pre_port "                       shininess 1~%")
    (fprintf pre_port "                       transparency 0 } }~%")
    (fprintf pre_port "                     geometry Text { ~%")
    (fprintf pre_port "                      string [\"Z\"] } } ] }~%")
    (fprintf pre_port "                  DEF controlRodTrans Transform  { children [~%")
    (fprintf pre_port "                    DEF controlPosRotSensor SphereSensor {}~%")
    (fprintf pre_port "                    Transform {~%")
    (fprintf pre_port "                     rotation 0 0 1 1.570796326794895~%")
    (fprintf pre_port "                     translation 0.575 0 0~%")
    (fprintf pre_port "                     children [~%")
    (fprintf pre_port "                      Shape {~%")
    (fprintf pre_port "                       appearance Appearance {~%")
    (fprintf pre_port "                        material Material {~%")
    (fprintf pre_port "                         diffuseColor 0.8 0.8 0.8~%")
    (fprintf pre_port "                         ambientIntensity 1~%")
    (fprintf pre_port "                         specularColor 0.8 0.8 0.8~%")
    (fprintf pre_port "                         emissiveColor 0.1 0.1 0.1~%")
    (fprintf pre_port "                         shininess 1~%")
    (fprintf pre_port "                         transparency 0.5 } }~%")
    (fprintf pre_port "                       geometry Cylinder {~%")
    (fprintf pre_port "                        radius 0.25 ~%")
    (fprintf pre_port "                        height 0.25 } } ] }~%")
    (fprintf pre_port "                    Transform  { ~%")
    (fprintf pre_port "                     translation      1 0 0 ~%")
    (fprintf pre_port "                     scale            4 1 1~%")
    (fprintf pre_port "                     children [~%")
    (fprintf pre_port "                      DEF PlasmAnimPosSensor TouchSensor {} ~%")
    (fprintf pre_port "                      DEF PlasmAnimPos Script {~%")
    (fprintf pre_port "                       eventIn  SFVec3f hitPoint_changed~%")
    (fprintf pre_port "                       eventOut SFFloat time_changed ~%")
    (fprintf pre_port "                       eventOut SFVec3f translation~%")
    (fprintf pre_port "                       eventOut MFString posText~%")
    (fprintf pre_port "                       field SFInt32 approx 0~%")
    (fprintf pre_port "                       url \"javascript: ~%")
    (fprintf pre_port "                            function hitPoint_changed(pos, ts) {~%")
    (fprintf pre_port "                               if(pos.x>0 && pos.x<1) {~%")
    (fprintf pre_port "                                  translation.x=pos.x;~%")
    (fprintf pre_port "                                  approx=100 * (~a*pos.x);~%" tEnd)
    (fprintf pre_port "                                  time_changed=pos.x * ~a; }~%" tEnd)
    (fprintf pre_port "                               else if(pos.x<=0) {~%")
    (fprintf pre_port "                                  translation.x=0;~%")
    (fprintf pre_port "                                  time_changed=0;~%")
    (fprintf pre_port "                                  approx=0; }~%")
    (fprintf pre_port "                               else if(pos.x>=1) {~%")
    (fprintf pre_port "                                  translation.x=1;~%")
    (fprintf pre_port "                                  approx=~a*100;~%" tEnd)
    (fprintf pre_port "                                  time_changed=~a; } }~%" tEnd)
    (fprintf pre_port "                            function eventsProcessed( ) {  ~%")
    (fprintf pre_port "                               posText[0]='t = ' +  approx/100; }\" }~%")
    (fprintf pre_port "                      DEF PlasmAnimPosIndicator Transform  { ~%")
    (fprintf pre_port "                       rotation 0 0 1 1.570796326794895 ~%")
    (fprintf pre_port "                       children [~%")
    (fprintf pre_port "                        DEF smallCylinderInd Shape {~%")
    (fprintf pre_port "                         appearance Appearance {~%")
    (fprintf pre_port "                          material Material {~%")
    (fprintf pre_port "                           diffuseColor 0.6 0 0~%")
    (fprintf pre_port "                           ambientIntensity 1~%")
    (fprintf pre_port "                           specularColor 0.6 0 0~%")
    (fprintf pre_port "                           emissiveColor 0.1 0 0~%")
    (fprintf pre_port "                           shininess 1~%")
    (fprintf pre_port "                           transparency 0.25 } }~%")
    (fprintf pre_port "                         geometry Cylinder { ~%")
    (fprintf pre_port "                          radius 0.25  ~%")
    (fprintf pre_port "                          height 0.01 } } ] }~%")
    (fprintf pre_port "                      Transform  { ~%")
    (fprintf pre_port "                       translation      -0.01 0 0    ~%")
    (fprintf pre_port "                       rotation 0 0 1 1.570796326794895 ~%")
    (fprintf pre_port "                       children [~%")
    (fprintf pre_port "                        USE smallCylinderInd ] }~%")
    (fprintf pre_port "                      Transform  { ~%")
    (fprintf pre_port "                       translation      0.5 0 0    ~%")
    (fprintf pre_port "                       rotation 0 0 1 1.570796326794895 ~%")
    (fprintf pre_port "                       children [~%")
    (fprintf pre_port "                        Shape {~%")
    (fprintf pre_port "                         appearance Appearance {~%")
    (fprintf pre_port "                          material Material {~%")
    (fprintf pre_port "                           diffuseColor 0 0 0.6~%")
    (fprintf pre_port "                           ambientIntensity 1~%")
    (fprintf pre_port "                           specularColor 0 0 0.6~%")
    (fprintf pre_port "                           emissiveColor 0 0 0.1~%")
    (fprintf pre_port "                           shininess 1~%")
    (fprintf pre_port "                           transparency 0.25 } }~%")
    (fprintf pre_port "                         geometry Cylinder { ~%")
    (fprintf pre_port "                          radius 0.125~%")
    (fprintf pre_port "                          height 1.00 } } ] }~%")
    (fprintf pre_port "                     Transform  { ~%")
    (fprintf pre_port "                       translation      1.01 0 0    ~%")
    (fprintf pre_port "                       rotation 0 0 1 1.570796326794895 ~%")
    (fprintf pre_port "                       children [~%")
    (fprintf pre_port "                        USE smallCylinderInd ] }~%")
    (fprintf pre_port "                     Transform  { ~%")
    (fprintf pre_port "                      translation      0.25 0.25 0 ~%")
    (fprintf pre_port "                      scale 0.125 0.5 0.5 ~%")
    (fprintf pre_port "                      children [~%")
    (fprintf pre_port "                       Shape {~%")
    (fprintf pre_port "                        appearance Appearance {~%")
    (fprintf pre_port "                         material Material {~%")
    (fprintf pre_port "                          diffuseColor 0 0 0.3~%")
    (fprintf pre_port "                          ambientIntensity 1~%")
    (fprintf pre_port "                          specularColor 0 0 0.3~%")
    (fprintf pre_port "                          emissiveColor 0 0 0.1~%")
    (fprintf pre_port "                          shininess 1~%") 
    (fprintf pre_port "                          transparency 0.25 } }~%")
    (fprintf pre_port "                        geometry DEF PlasmAnimPosText Text  { ~%")
    (fprintf pre_port "                         string [\"t = 0.0\"] } } ] } ] ~%")
    (fprintf pre_port "                    ROUTE PlasmAnimPosSensor.hitPoint_changed TO PlasmAnimPos.hitPoint_changed~%")
    (fprintf pre_port "                    ROUTE PlasmAnimPos.translation TO PlasmAnimPosIndicator.translation ~%")
    (fprintf pre_port "                    ROUTE PlasmAnimPos.posText TO PlasmAnimPosText.string } ~%")
    (fprintf pre_port "                   Transform  { ~%")
    (fprintf pre_port "                    translation      5.5 0 0    ~%")
    (fprintf pre_port "                    children [~%")
    (fprintf pre_port "                    DEF PlaySensor TouchSensor {} ~%")
    (fprintf pre_port "                    Transform  { ~%") 
    (fprintf pre_port "                     rotation 0 0 1 -1.570796326794895 ~%")
    (fprintf pre_port "                     children [~%")
    (fprintf pre_port "                      Shape {~%")
    (fprintf pre_port "                       appearance Appearance {~%")
    (fprintf pre_port "                        material Material {~%")
    (fprintf pre_port "                         diffuseColor 0 0.6 0~%")
    (fprintf pre_port "                         ambientIntensity 1~%")
    (fprintf pre_port "                         specularColor 0 0.6 0~%")
    (fprintf pre_port "                         emissiveColor 0 0.1 0~%")
    (fprintf pre_port "                         shininess 1~%")
    (fprintf pre_port "                         transparency 0.25 } }~%")
    (fprintf pre_port "                       geometry Cone { ~%")
    (fprintf pre_port "                        bottomRadius 0.25     ~%")
    (fprintf pre_port "                        height       0.5 } } ] }~%")
    (fprintf pre_port "                    Transform  { ~%")
    (fprintf pre_port "                     translation      -0.25 0.25 0    ~%")
    (fprintf pre_port "                     scale 0.5 0.5 0.5~%")
    (fprintf pre_port "                     children [~%")
    (fprintf pre_port "                      Shape {~%")
    (fprintf pre_port "                       appearance Appearance {~%")
    (fprintf pre_port "                        material Material {~%")
    (fprintf pre_port "                         diffuseColor 0 0.3 0~%")
    (fprintf pre_port "                         ambientIntensity 1~%")
    (fprintf pre_port "                         specularColor 0 0.3 0~%")
    (fprintf pre_port "                         emissiveColor 0 0.1 0~%")
    (fprintf pre_port "                         shininess 1~%")
    (fprintf pre_port "                         transparency 0.25 } }~%")
    (fprintf pre_port "                       geometry Text { ~%")
    (fprintf pre_port "                        string [\"Play\"] } } ] } ] } ] } ] } ] } ] } ]~%")
    (fprintf pre_port "           ROUTE controlPosTransSensorXY.translation_changed TO controlGlobalTransXY.translation~%")
    (fprintf pre_port "	          ROUTE controlPosTransSensorXZ.translation_changed TO controlGlobalTransXZ.translation~%")
    (fprintf pre_port "           ROUTE controlPosTransSensorYZ.translation_changed TO controlGlobalTransYZ.translation~%")
    (fprintf pre_port "           ROUTE controlPosRotSensor.rotation_changed TO controlRodTrans.rotation } ]~%")
    (fprintf pre_port " whichChoice 0 }~%")
    (fprintf pre_port "DEF StopSensor TouchSensor {} # indentation resumed at previous position~%")

    (fprintf post_port "] # indentation temporarly suspended~%")
    (fprintf post_port "ROUTE PlasmAnimPos.time_changed  TO PlasmAnimTimerSwitch_~a.set_time~%" id)
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch.time_changed  TO PlasmAnimTimerSwitch_~a.set_time~%" id)
    (fprintf post_port "ROUTE PlasmAnimTimerSwitch.whichChoice TO PlasmAnimSwitch.whichChoice~%")
    (fprintf post_port "ROUTE PlasmAnimTimer.fraction_changed TO PlasmAnimTimerSwitch.set_fraction~%")
    (fprintf post_port "ROUTE PlasmAnimTimer.isActive TO PlasmAnimTimerSwitch.isActive~%")
    (fprintf post_port "ROUTE PlaySensor.touchTime TO PlasmAnimTimer.startTime~%")
    (fprintf post_port "ROUTE StopSensor.touchTime TO PlasmAnimTimer.stopTime~%")
    (fprintf post_port "} # END Plasm ANIMATION, indentation  resumed at previous position~%")

    (set! anim (anim_prop_VRMLanimation (anim-pol-complex-pol anim) pre_port post_port))
    anim))





; plasm definition are in f_envs.scm

(newline)
(display "PLaSM Animation Extension Enabled")
(newline)
