;==================================================
; MzPlasm
; Author:
;     Giorgio Scorzelli     
; DATE: January 2001
;==================================================

;*********************PIT**************************
;**************Alessandro La Rosa******************
(define (ceq x)
  (lambda (y)
    (= x y)))
(define (notceq x)
  (lambda (y)
    (not (= x y))))

(define (square-mat m)
  (and (list? m) (every list? m) (every (ceq (length m)) (map length m))))
(define (ismat m)
  (or (and (pair? m) (every list? m) (every (ceq (length (car m))) (map length m))) (null? m)))
;*********************PIT***************************

(define (submatrix source i j)
    (let row-loop ([row 0])
      (cond 
        [(eq? row (length source)) null]
        [(eq? row i) (row-loop (+ row 1))]
        [else
         (cons 
          (let col-loop ([col 0])
            (cond 
              [(eq? col (length (car source))) null]
              [(eq? col j) (col-loop (+ col 1))]
              [else
               (cons (list-ref (list-ref source row) col)
                     (col-loop (+ col 1)))]))
          (row-loop (+ row 1)))])))


(define (det matrix)
  (if (null? matrix)
      1
      (if (square-mat matrix)
          (let loop ([row 0] [sign 1])
            (if (= row (length matrix))
                0
                (+ (* sign
                      (list-ref (list-ref matrix row) 0)
                      (det (submatrix matrix row 0)))
                   (loop (+ row 1) (- sign)))))
          1)))


(define (matrix-invert matrix)
  (let-values ([(width height) (matrix-dimension matrix)])
    (when (not (= width height))
      (error 'invert "matrix is not square: ~s" matrix))
    (let ([delta-inv (/ 1 (det matrix))])
      (let row-loop ([row 0] [sign 1])
        (if (= row (length matrix))
            null
            (cons 
             (let col-loop ([col 0] [sign sign])
               (if (= col (length (car matrix)))
                   null
                   (cons (* delta-inv
                            sign
                            (det (submatrix matrix col row)))
                         (col-loop (+ col 1) (- sign)))))
             (row-loop (+ row 1) (- sign))))))))


(define (matrix-dimension matrix)
  (when (not (pair? matrix))
    (error 'matrix-dimension "matrix argument is not a list: ~s" matrix))
  (let ([height (length matrix)])
    (when (= height 0)
      (error 'matrix-dimension "matrix argument is empty: ~s" matrix))
    (when (not (pair? (car matrix)))
      (error 'matrix-dimension "matrix row is not a list: ~s" (car matrix)))
    (let ([width (length (car matrix))])
      (when (= width 0)
        (error 'matrix-dimension "matrix argument has width 0: ~s" matrix))
      (let loop ([rows matrix])
        (if (null? rows)
            (values width height)
            (begin
              (when (not (pair? (car rows)))
                (error 'matrix-dimension "row is not a list: ~s" (car rows)))
              (when (not (= width (length (car rows))))
                (error 'matrix-dimension "rows have different widths: ~s and ~s" width (length (car rows))))
              (loop (cdr rows))))))))


(define (transpose vector) (apply map list vector))


(define (apl-style-function fn)
  (lambda (a b)
    (if (number? a)
        (fn a b)
        (map (apl-style-function fn) a b))))

(define matrix-add (apl-style-function +))
(define matrix-sub (apl-style-function -))
(define vector-multiply (apl-style-function *))
(define vector-divide (apl-style-function /))


(define (list-sum a)
	(empty? a)
		0
		(+ (car a) (list-sum (cdr a))))


 (define (inner-product a b)
    (foldl + 0 (map * a b)))
  

  
(define (matrix-multiply a b)
  (let-values ([(width-a height-a) (matrix-dimension a)]
               [(width-b height-b) (matrix-dimension b)])
    (when (not (= width-a height-b))
      (error 'matrix-multiply "matrix dimensions do not match for multiplication"))
    (let ([b-t (transpose b)])
      (map (lambda (row)
             (map (lambda (col)
                    (inner-product row col))
                  b-t))
           a))))






