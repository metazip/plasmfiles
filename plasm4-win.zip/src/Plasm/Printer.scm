; move somewhere else, however not in PlasmAnim.scm as that has to be loaded aftere f_envs.scm
(define-struct anim-pol-complex (pol id tStart tEnd))


(define (Plasm_Printer plasmobj port)
  (if (not (output-port? port)) 
      (set! port (current-output-port)))
  
  (let loop ((obj plasmobj))
    
    ; *** SYMBOL ****
    (if (symbol? obj)
    	(if (not (eq? obj 'Plasm_value))
        (begin 
					(display "==================" port) (newline)
          (display obj port)
          (display " DEFINED" port) (newline)
					(display "==================" port) )))
    
    ; *** NUMBER ****
    (if (or (number? obj) (char? obj))  
        (begin
          (display obj port)))
    
    ; *** STRING ****
    (if (string? obj) 
        (begin (display #\' port)
               (display obj port)
               (display #\' port)))
    
    ; *** PROCEDURE ****
    (if (procedure? obj)
        (if (isclass obj) 
            (begin
              (display "Plasm Class ")
              (display (obj '�_name_�)))
            (if (isobject obj)
                (begin
                  (display "Plasm Object of Class ")
                  (PrintObj obj port))
                (display "An-Anonymous-Function" port))))
    
    ; *** POL COMPLEX ****
    (if (and *USE_GEOMETRY* (pol-complex? obj))
        (begin
          (display "PolComplex ")
          ;(newline)
          (Plasm_Printer `(,(send obj get-dpol-dim),(send obj get-npol-dim)) port)))

    (if (and *USE_GEOMETRY* (anim-pol-complex? obj))
        (begin
          (display "AnimPolComplex:")
	  (newline)
	  (display "   Id:")
	  (display (anim-pol-complex-id obj))
	  (newline)
	  (display "   tStart=")
	  (display (anim-pol-complex-tStart obj))
	  (newline)
	  (display "   tEnd=")
	  (display (anim-pol-complex-tEnd obj))
	  (newline)
	  (display "   ")
	  (Plasm_Printer (anim-pol-complex-pol obj) port)))
    
    ; *** BOOLEAN ****
    (if (boolean? obj) 
        (if obj (display "True") (display "False")))
    
    ; *** LIST ****
    (if (list? obj)
        (if (null? obj)
            (display "<>" port)
            (let ((in_str (if (every char? obj) #t #f)))
              
              (if in_str (display "'") (display "< " port) )
              (loop (car obj))
              
              
              (for-each (lambda (item) 
                          (if (not in_str)  (display " , " port))
                          (loop item))
                        
                        (cdr obj))
              (if in_str (display "'") (display " >" port))
              )))

    ; *** PROPERTIES ***
	(if (or (list? obj) (number? obj) (char? obj) (string? obj) (boolean? obj) (procedure? obj)
		(and *USE_GEOMETRY* (pol-complex? obj)))
		(if (has-property? obj)
    	(let ((props (plasm-list-gp obj)))
	      ;(display props)
		  (if (not (null? props))
		  (begin 
		    (display " $ ")
		    (loop props ))))))
	  
	  
	
    )
  (newline))


(define (PrintObj obj port)
  (let ((value (obj '�_value_�)))
    (display ((obj '�_class_�) '�_name_�))
    (display " ")
    (if (isobject value) 
	(PrintObj value port)
	(begin
	  (display "and Value ")
	  (Plasm_Printer value port)))))

    
