;==================================================
; MzPlasm
; Author:
;     Simone Portuesi
; Revision:
;     Giorgio Scorzelli
;     Stefano Francesi
; DATE: January 2001
; REVISION : August 2001
;==================================================


;; -----------------------------------------------------------------
;; Usate dal LEx
;; -----------------------------------------------------------------

;; semantica diretta 
;; restituisce una forma scheme valutabile

(define *Current_Script_Elem_Text* "")

(define (Syntax_User_Action str)
  (set! *Current_Script_Elem_Text* (string-append *Current_Script_Elem_Text* str)))

(define (Syntax_Error str)
  
  

  ; find last \n , make a utility function
  ;(do ((l (string-length *Current_Script_Elem_Text*))
   ;    (old_cnt 0 cnt)
   ;    (cnt 0 (+ cnt (substring? "\n" (substring  *Current_Script_Elem_Text* cnt l)) 1)))
   ;   ((not cnt) old_cnt)
   ; (display (substring  *Current_Script_Elem_Text* cnt l))
   ; (newline)
   ; (display (substring? "\n" (substring  *Current_Script_Elem_Text* cnt l)))
   ; (newline)
   ; (display cnt)
   ; (newline)
   ; (display "-----------------------------------------------------------")
   ; (newline)
   ; )
     

  (set! *Current_Script_Elem_Text* (string-append *Current_Script_Elem_Text* " -> " str)))



(define (Syntax_string str) 
  (substring str 1 (1- (string-length str))))
; (Syntax_Seq (string->list (substring str 1 (1- (string-length str))))))

(define (Syntax_number str) 
  (string->number str))


(define (Syntax_identifier str) 
  (string->symbol-ci str))
  

(define (Syntax_selop str)
  `((get-env *env* 'apply) 
    ,(Syntax_Seq 
      `((get-env *env* 'sel) 
	,(string->number (substring str 1 (string-length str)))))))

(define (Syntax_skelop str) 
  `((get-env *env* 'apply) 
    ,(Syntax_Seq 
      `((get-env *env* 'skeleton) 
	,(string->number (substring str 1 (string-length str)))))))

;(define (Syntax_Seq seq) (list 'quasiquote (map (lambda (elem) (list 'unquote elem)) seq)))

;(define (Syntax_Seq seq) `(list ,@(map (lambda (elem) elem) seq)))

;(define (Syntax_Seq seq) `(list ,@seq))

(define (Syntax_Seq seq) 
  `((get-env *env* 'list) ,@seq))




;(define (Syntax_Lambda_prob name params body)
;; codice sperimentale se da problemi reinserire il vechio!
  
;  (append
   
;       `(let ((*env* (add-env (make-env make-val-def (make-list-assoc)) *env*))))
       

;   (list
;    (do ((eval_form body)
;	 (params_todo params (cdr params_todo)))
;	((null? params_todo) eval_form)
;;      (display (car params_todo))(newline)(display params_todo)(newline)
;      (let ((lambda_form '(lambda (args)))
	    
;	    ; let: le sotto-variabili non vedono gli argomenti
;	    ;   es. DEF a=n; n -> unbound; DEF b (n::IsNum) = a +n; b:1 -> error
;	    ; fluid-let: le sotto-espressionivedono gli argomenti
;	    ;   es. DEF a=n; n -> unbound; DEF b (n::IsNum) = a +n; b:1 -> 2
;	    ; problema: nel secondo caso le dipendenze vanno un po' a puttane
	    
;	    ; pre-valutazione, qui puo dare problemi
;	    ;(arg-env_init_form `(let ((*env* (add-env ,(make-env make-def (make-list-assoc)) *env*)))))
;	    (arg-env_fill_form 
;	     (map (lambda (param)
;		    (let ((arg_name (car param))
;			  (arg_pred (eval (cadr param)))
;			  (arg_sel (eval (caddr param))))
;		      ;`(display args)
;		      `(if (,arg_pred (,arg_sel args))
;			   (*env* 'def ',arg_name (lambda () (,arg_sel args)))
;			   (plasm-exception (list ,(symbol->string name) 
;						  ,(symbol->string arg_name) 
;						  (,arg_sel args)))
;			   )
		     
;))
;		  (car params_todo)))
	    
;	    )
;	(set! eval_form 
;	      (append 
;	       lambda_form 
;	       ;(list 
;		;(append 
;		 ;arg-env_init_form 
;		 (append 
;		  arg-env_fill_form
;		  (list eval_form)
;		    )
;		 ;)
;		 ;)
;))
;	))

;)
;   ))


(define (Syntax_Lambda name params body)
    (do ((eval_form body)
	 (params_todo params (cdr params_todo)))
	((null? params_todo) eval_form)

      (let ((lambda_form '(lambda (args)))
	    
	    ; let: le sotto-variabili non vedono gli argomenti
	    ;   es. DEF a=n; n -> unbound; DEF b (n::IsNum) = a +n; b:1 -> error
	    ; fluid-let: le sotto-espressionivedono gli argomenti
	    ;   es. DEF a=n; n -> unbound; DEF b (n::IsNum) = a +n; b:1 -> 2
	    ; problema: nel secondo caso le dipendenze vanno un po' a puttane
	    
	    
	    (arg-env_init_form `(let ((*env* (add-env (make-env make-val-def (make-list-assoc)) *env*)))))
	    (arg-env_fill_form 
	     (map (lambda (param)
		    (let ((arg_name (car param))
			  (arg_pred (cadr param))
			  (arg_sel (caddr param)))
		      ;`(display args)					       
					       
		      ;optimized but not for animations
		      ;`(if (,arg_pred (,arg_sel args))
                      ;(*env* 'def ',arg_name (lambda () (,arg_sel args)))
                      ;(plasm-exception (list ,(symbol->string name) 
                      ;                       ,(symbol->string arg_name) 
                      ;			      (,arg_sel args))))
		      ; Completly Plasm compilant, thus redefinable 
		      ; a redefinition is animation support
		      ; may be optimized, but only wrt a single redefinition
		      `(*env* 
			'def 
			',arg_name 
			(lambda ()
			  ((get-env *env* 'apply)
			   ((get-env *env* 'list)
			    ((get-env *env* 'apply)
			     ((get-env *env* 'list)
			      (get-env *env* 'if)
			      ((get-env *env* 'list)
			       ((get-env *env* 'apply)
				((get-env *env* 'list)
				 (get-env *env* '~)
				 ((get-env *env* 'list) ,arg_pred ,arg_sel)))
			       ,arg_sel
			       ((get-env *env* 'apply)
				((get-env *env* 'list)
				 (get-env *env* '~)
				 ((get-env *env* 'list)
				  (get-env *env* 'signal)
				  ((get-env *env* 'apply)
				   ((get-env *env* 'list)
				    (get-env *env* 'cons)
				    ((get-env *env* 'list)
				     ((get-env *env* 'apply)
				      ((get-env *env* 'list) 
				       (get-env *env* 'k) 
				       ,(symbol->string name)))
				     ((get-env *env* 'apply)
				      ((get-env *env* 'list) 
				       (get-env *env* 'k) 
				       ,(symbol->string arg_name)))
				     (get-env *env* 'id))))))))))
			    args))))))
		  (car params_todo))))
	(set! eval_form 
	      (append 
	       lambda_form 
	       (list 
		(append 
		 arg-env_init_form 
		 (append 
		  arg-env_fill_form
		  (list eval_form)))))))))


(define (Syntax_Loc locals body)
  (if (null? locals) body
      (append 
       
       `(let ((*env* (add-env (make-env make-def (make-hash-assoc)) *env*))))
       
	     (append locals   (list body)  )))
)
	  
      


(define (Syntax_Def name params body locals)
  (let* 
      (
       (locals_form (Syntax_Loc locals  body)) 
       (lambdas_form (Syntax_Lambda name params locals_form))
       )
       `(*env* 'def ',name (eval ,(append `(lambda () ,lambdas_form))))
    
       ))
   




(define (Syntax_Object name params isa body locals)
  
 (letrec ((arg-env_fill_form 
	   (map (lambda (param)
		  (let ((arg_name (car param))
			(arg_pred (cadr param))
			(arg_sel (caddr param)))
		    `(if (,arg_pred (,arg_sel args))
			 (*env* 'def ',arg_name (lambda () (,arg_sel args)))
			 (plasm-exception (list ,(symbol->string name) 
						,(symbol->string arg_name) 
						(,arg_sel args)))
			 )
		    
		    ))
		(car params)))
	  ; (loc-env_fill_form ...)
	  ;(val-env_fill_form '((*env* 'def '�_object_� (lambda () body))))
	  (object_env_form '(let* ((*object_env* (make-env make-def (make-list-assoc)))
				     (*env* (add-env *object_env*  *env*)))))
	  
	  (super_form 
	   `(
	       (*env* 'def 'super 
		      (lambda ()
			 (let ((res ,body))
			   (if ((get-env *env* (string->symbol (string-append "is" (symbol->string ',isa)))) res)
			       res
			       ((get-env *env* ',isa) res)))))
	       
	       (set! *object_env* (add-env *object_env*  ((get-env *env* 'super) '�_object_env_�)))
	       (set! *class_env* (add-env *class_env* ((get-env *env* 'super) '�_class_env_�)))))
					   
	  
	  (value_form 
		  `((*env* 'def 'this ,(append `(lambda () ,body)))))
	      
	
	  (object_form
	   `(letrec 
		(
		 (plasm_object
		  (lambda (args)
		    (case args
		      ('�_class_env_� *class_env*)
		      ('�_class_� plasm_class)
		      ('�_isclass_� #t)
		      ('�_object_env_� *object_env*)
		      ('�_isobject_� #t)
		      ('�_point_� (add-env *object_env* *class_env*))
		      ('�_value_� (get-env *object_env* 'this))
		      (else (plasm-exception (list ',name "is a Object")))
		      ))))
	      plasm_object))
	   )
	  (append  object_env_form 
		   arg-env_fill_form 
		   locals 
		   (if (null? isa) value_form  super_form )
		   (list object_form))))
		 



; versione semplice, meglio di quella compless (environment vedono plasm-class)
(define (Syntax_Class name params isa body locals)
 `(let ((*class_env* (make-env make-def (make-list-assoc))))
    (*class_env* 'def 'is 
		 (lambda () 
		   (lambda (arg) 
		     (if (eq? (get-env *env* ',name) arg) 
			 #t
			 ,(if (null? isa) 
			      #f
			      `((((get-env *env* ',isa) '�_class_env_�) 'get 'is) arg)
			      )))))

	(letrec ((plasm_class 
		  (lambda (args)
		    
		    (case args
		      ('�_class_env_� *class_env*)
		      ('�_point_� *class_env*)
		      ('�_class_� plasm_class)
		      ('�_name_� ',name)
		      ('�_isclass_� #t)
		      (else 
		       ,(Syntax_Object name params  isa body locals))
		      ))))
	  plasm_class )))

(define (Syntax_Def_Class name params isa body locals)
  ;(display "Syntax_Class")
  ;(display `(,name ,params ,isa ,body ,locals))
  ;(newline)

  (letrec ((class_form 
	    
	    (Syntax_Class name params isa body locals)
	    ))


    ; questo piu meno va bene
    `(begin
       (*env* 'def ',name (eval (lambda () ,class_form)))
       ;(*env* 'def 
;	      ',(string->symbol (string-append "is" (symbol->string name)))
;	      (eval (lambda () 
;		       (lambda (arg) 
;			 ((((*env* 'get ',name) '�_point_�) 'get 'is) arg)))))
       ; forse e' meglio
       ; ome un control di default
       (*env* 'def 
	      ',(string->symbol (string-append "is" (symbol->string name)))
	      (eval (lambda () 
		       (lambda (arg)
			 ; attenzione e' dipendente da mzscheme 
			 ; -> trovare alternativa
			 (if (isobject arg)
			     (((arg '�_class_env_�) 'get 'is) (*env* 'get ',name))
			     #f)))))
       )
    ))



;creare funzioni plasm
(define inferred-name object-name)
(define (isclass arg) (eq? (inferred-name arg) 'plasm_class))
(define (isobject arg) (eq? (inferred-name arg) 'plasm_object))
; estendere per environment reali
(define (isenv arg) (or (isclass arg) (isobject arg)))



(define (Syntax_Feature name  params on expr locals)
  
  (let* (
	 (last_param `((this 
		       (get-env *env* ',(string->symbol (string-append "is" (symbol->string on))))
		       (lambda (id) id))))
	 (params (cons last_param params))
	 (expr `(let ((res ,expr))
		  (if ((get-env *env* ',(string->symbol (string-append "is" (symbol->string on)))) res)
		      res
		      ((get-env *env* ',on) res))))
	 (locals_form (Syntax_Loc locals  expr)) 
	 (lambdas_form (Syntax_Lambda name params locals_form))
	 )
    `(if (isclass (get-env *env* ',on))
	 (begin
	   (((get-env *env* ',on) '�_class_env_�) 
	    'def ',name (eval ,(append `(lambda ()  ,lambdas_form))))
	   (((get-env *env* ',on) '�_class_env_�) 
	    'def 
	    ',(string->symbol (string-append (symbol->string name)  "_arity"))
	    (lambda () ,(length params))))
	(plasm-exception (list ,(symbol->string name) "no such class")))))
    
 
	   
(define (Syntax_Def_Feature id params on expr locals)
  (letrec (
	   (uncurry (lambda (f args)
		      (do ((res (f (car args)) (res (car todo)))
			     (todo (cdr args) (cdr todo)))
			  ((null? todo) res))))
	   (parse_args 
	    (lambda (args)
	      (lambda (arg)
		;(set! args (append args (list arg)))
		(if (isobject arg)
		    (let (
			  (fun ((arg '�_class_env_�) 'get id))
			  (pos ((arg '�_class_env_�) 
				'get 
				(string->symbol (string-append (symbol->string id)  "_arity"))))
			  )
		      (if (and (not (eq? fun '�_np_�))
			       (= pos (+ (length args) 1)))
			      (uncurry fun (append args (list arg)))
			      (parse_args (append args (list arg)))
			      ))
		    (parse_args (append args (list arg)))))))
	   )
    `(begin 
      ,(Syntax_Feature id params on expr locals)
      (*env* 'def ',id (lambda () (,parse_args '())))
      )
    ))

(define (Syntax_Control name  params on expr locals)
  
  (let* (
	 (last_param `((this 
		       (get-env *env* ',(string->symbol (string-append "is" (symbol->string on))))
		       (lambda (id) id))))
	 (params (cons last_param params))
	 (locals_form (Syntax_Loc locals  expr)) 
	 (lambdas_form (Syntax_Lambda name params locals_form))
	 )
    `(if (isclass (get-env *env* ',on))
	 (begin
	   (((get-env *env* ',on) '�_class_env_�) 
	    'def ',name (eval ,(append `(lambda ()  ,lambdas_form))))
	   (((get-env *env* ',on) '�_class_env_�) 
	    'def 
	    ',(string->symbol (string-append (symbol->string name)  "_arity"))
	    (lambda () ,(length params))))
	(plasm-exception (list ,(symbol->string name) "no such class")))))
    
    
 
   

; e' uguale a features -> unificare  
(define (Syntax_Def_Control id params on expr locals)
  (letrec (
	   (uncurry (lambda (f args)
		      (do ((res (f (car args)) (res (car todo)))
			     (todo (cdr args) (cdr todo)))
			  ((null? todo) res))))
	   (parse_args 
	    (lambda (args)
	      (lambda (arg)
		;(set! args (append args (list arg)))
		(if (isobject arg)
		    (let (
			  (fun ((arg '�_class_env_�) 'get id))
			  (pos ((arg '�_class_env_�) 
				'get 
				(string->symbol (string-append (symbol->string id)  "_arity"))))
			  )
		      (if (and (not (eq? fun '�_np_�))
			       (= pos (+ (length args) 1)))
			      (uncurry fun (append args (list arg)))
			      (parse_args (append args (list arg)))
			      ))
		    (parse_args (append args (list arg)))))))
	   )
    `(begin 
      ,(Syntax_Control id params on expr locals)
      (*env* 'def ',id (lambda () (,parse_args '())))
      )
    ))		      

(define Syntax-Rules 
  `#( 
     ,(lambda every (display "Called Zero Prod")(newline) '())
     ; input: 2
     ;/* empty */ 
    ; ,(lambda () '())    
     ; script 
     ,(lambda (script) 
	(if *RET_VAL* script))
     ; script script_elem 
     ,(lambda (script script_elem) 
	  (if (memq 'expr_text *DEBUG*)
	      (begin
		(display "Expression Text:")
		(newline)
		(display *Current_Script_Elem_Text* )
		(newline)
		(newline)))
	  (if (memq 'eval_form *DEBUG*)
	      (begin
		(display "Auto-Eval-Form :")
		(newline)
		(pretty-display script_elem)
		(newline)
		(newline)))

	  (newline)
	 
	  (let ((ret 
		 (call-with-current-continuation 
		  (lambda (exception_h)
		    (fluid-let (
;				(error-handler 
;				(lambda arg (exception_h (cons 'Scheme_error arg))))
				
				(plasm-exception 
				 (lambda (arg) (exception_h (cons 'Plasm_exception arg)))))
		      (cons 'Plasm_value (eval script_elem))))
		     )))
	     ; to be moved?!
	    (case (car ret) 
	      ('Scheme_error (begin
			       (display "Scheme error! (report bug):")
			       (newline)
			       (display (cdr ret))))
	      ('Plasm_exception (begin
				  (display "Plasm Exception:")
				  (newline)
				  (Plasm_Printer (cdr ret) #t)))
	      ('Plasm_value (begin
			      ; added at the last moment to support a last_value variable
			      (if (not (symbol? (cdr ret)))
				  (*env* 'def 'last_value (lambda () (cdr ret))))
			      (Plasm_Printer (cdr ret) #t))))
	    
	    (set! *Current_Script_Elem_Text* "")
	    (newline)
	    
	    (if *RET_VAL* 
		(append script (list ret)))
	    ))
     ; script  error
     ,(lambda (script error) 
	;(display "------------------------------------------------------------------------------")
	(newline)
	(display "Plasm Parser Error:")
	(newline)
	;(display "Expression Text: \n")
	(display *Current_Script_Elem_Text* )
	(set! *Current_Script_Elem_Text* "")
	(newline)
	(newline)
	(if *RET_VAL* script)


	)

     ; script:
     ; empty
     ,(lambda () '())    
     
     ; script  script_elem ';'
     ,(lambda (script script_elem semic) 

	(if (memq 'expr_text *DEBUG*)
	      (begin
		(display "Expression Text:")
		(newline)
		(display *Current_Script_Elem_Text* )
		(newline)
		(newline)))
	  (if (memq 'eval_form *DEBUG*)
	      (begin
		(display "Auto-Eval-Form :")
		(newline)
		(pretty-display script_elem)
		(newline)
		(newline)))

	  (newline)
	 
	  (let ((ret 
		 (call-with-current-continuation 
		  (lambda (exception_h)
		    (fluid-let (
;				;(error-handler 
;				; (lambda arg (exception_h (cons 'Scheme_error arg))))
				
				(plasm-exception 
				 (lambda (arg) (exception_h (cons 'Plasm_exception arg)))))
		      (cons 'Plasm_value (eval script_elem))))
		 
		     )))

	    ; to be moved?!
	    (case (car ret) 
	      ('Scheme_error (begin
			       (display "Scheme error! (report bug):")
			       (newline)
			       (display (cdr ret))))
	      ('Plasm_exception (begin
				  (display "Plasm Exception:")
				  (newline)
				  (Plasm_Printer (cdr ret) #t)))
	      ('Plasm_value (begin
				  (Plasm_Printer (cdr ret) #t))))
	    
	    
	    (set! *Current_Script_Elem_Text* "")
	    (newline)

	    (append script (list ret))
	    

	    ))
	   
	 
	  
	    
     ; script error ';'
     ,(lambda (script error semic) 
	;(display "------------------------------------------------------------------------------")
	(newline)
	(display "Plasm Parser Error:")
	(newline)
	;(display "Expression Text: \n")
	(display *Current_Script_Elem_Text* )
	(set! *Current_Script_Elem_Text* "")
	(newline)
	(newline)


	script
	)

	
     ; script_elem:
     ; expr 
     ,(lambda (expr) expr)
	
     ; defin
     ,(lambda (defin) defin)
     


     ; expr: 
     ; TOKENID 
     ,(lambda (TOKENID) `(get-env *env*  ',TOKENID))
     ; LEX_VALUE
     ,(lambda (LEX_VALUE) LEX_VALUE)
     ; '~'
     ,(lambda (op) `(get-env *env*  ',op))
     ; "**"
     ,(lambda (op) `(get-env *env*  ',op))
     ; '*'
     ,(lambda (op) `(get-env *env*  ',op))
     ; '/'
     ,(lambda (op) `(get-env *env*  ',op))
     ; '+' 
     ,(lambda (op) `(get-env *env*  ',op))
     ; '-'
     ,(lambda (op) `(get-env *env*  ',op))
     ; seq
     ,(lambda (seq) seq)
     ; expr: '(' expr ')' 
     ,(lambda (lpar expr rpar) expr)
     ; vede solo il locale o anche il sovrastante?
     ;  expr '.' expr
     ,(lambda (env point expr) `(if (isenv ,env) (let ((*env* (,env '�_point_�))) ,expr)))
	
     ;   ; expr: appl
     ;   ;,(lambda (appl) `((get-env *env*  'APPLY) ,(Syntax_Seq appl)
     ;   ; appl: 
     ; expr ':' expr
     ,(lambda (expr1 colom expr2) 
	`((get-env *env*  'apply) ,(Syntax_Seq `(,expr1 ,expr2))))
     ; expr '~' expr
     ,(lambda (expr1 op expr2) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env*  ',op) 
			 ,(Syntax_Seq `(,expr1 ,expr2))))))
     ; '[' exprseq ']' 
     ,(lambda (lpar exprseq rpar) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* 'cons) ,(Syntax_Seq exprseq)))))
     ; expr "**" expr
     ,(lambda (expr1 op expr2) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* ',op) 
			,(Syntax_Seq `(,expr1 ,expr2))))))
     ; expr '*' expr
     ,(lambda (expr1 op expr2) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* ',op) 
			 ,(Syntax_Seq `(,expr1 ,expr2))))))
     ; expr '/' expr
     ,(lambda (expr1 op expr2) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* ',op) 
			 ,(Syntax_Seq `(,expr1 ,expr2))))))
     ; expr '+' expr
     ,(lambda (expr1 op expr2) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* ',op) 
			 ,(Syntax_Seq `(,expr1 ,expr2))))))
     ; expr '-' expr
     ,(lambda (expr1 op expr2) 
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* ',op) 
			 ,(Syntax_Seq `(,expr1 ,expr2))))))
     ; - expr 
     ; crea grossi problemi: -~[...] -> parse error; -*ID ->parse error
     ;,(lambda (op expr) `((get-env *env* ',op) ,(Syntax_Seq `(,expr))))
     ; expr expr expr
     ,(lambda (expr1 op expr2) `((get-env *env*  'apply) ,(Syntax_Seq `(,op ,(Syntax_Seq `(,expr1 ,expr2))))))

     ; to handle on the fly moves
     ,(lambda (move_id colums expr)
	`((get-env *env*  'apply) 
	  ,(Syntax_Seq `((get-env *env* 'move)
			 (lambda (arg) ((get-env *env* 'apply) ,(Syntax_Seq `(,expr arg))))))))

     ; seq: 
     ; '<' exprseq '>'
     ,(lambda (lpar seq rpar) 
	(Syntax_Seq seq)
	;`(list ,@seq)
	)
     ; '<' '>'
     ,(lambda (lpar rpar) `(quote ()))

     ; exprseq:
     ; expr 
     ,(lambda (expr) `(,expr))
     ; exprseq ',' expr
     ,(lambda (exprseq coma expr) `(,@exprseq ,expr))

     ; defin: 
     ; "DEF" TOKENID params '=' expr locals defaults
     ,(lambda (def id params eq expr locals defaults) 
	; genera l'auto-eval della funzione 
	(Syntax_Def id params expr locals))
     ; "CLASS"  TOKENID params isa '=' expr locals
     ,(lambda (def id params isa eq expr locals) 
	(Syntax_Def_Class id params isa expr locals))
     ; "FEATURE" TOKENID params on '=' expr locals
     ,(lambda (def id params on eq expr locals) 
	(Syntax_Def_Feature id params on expr locals))

     ; "CONTROL" TOKENID params on '=' expr locals
     ,(lambda (def id params on eq expr locals) 
	(Syntax_Def_Control id params on expr locals))

     ;on:
     ; "ON" TOKENID
      ,(lambda (on id) id)
	 

     ;isa:
     ; /* empty */
     ,(lambda () '())
     ; "ISA" TOKENID
     ,(lambda (isa id) id)

     ; params:
     ; /* empty */
     ,(lambda () '())
     ; params '(' param_list ')'
     ,(lambda (params lpar param_list rpar)
	;	( (nomi) (condizioni) (selettori)
	(append  (list
		  (if (eq? (length param_list) 1) 
		      (list (append (car param_list) '((get-env *env* 'id))))
		      (let ((cnt 0))
			(map (lambda (param)
			       (set! cnt (1+ cnt))
			       (append param `(
					       ((get-env *env* 'SEL) ,cnt)
					       ))
			       )
			       
			     param_list)))) params)
	)
			       

     
     ; param_list:
     ; param
     ,(lambda (param) 
	param)
	
     ; param_list ';' param
     ,(lambda (param_list sep param) (append param_list param))

       
     ; param:
     ; idents "::" type
     ,(lambda (id sep type) (map (lambda(name) (list name type)) id))


     ; type:
     ; expr 
     ,(lambda (expr) expr)

     ; idents:
     ; TOKENID 
     ,(lambda (_1)  `(,_1))  
     ; idents ',' TOKENID
     ,(lambda (_1 _2 _3) `(,@_1 ,_3))

     ; locals:
     ; /*empty */
     ,(lambda () '())
     ; "WHERE" loc_def_list "END"
     ,(lambda (_1 _2 _3) _2)
     
     ; defaults:
     ; /*empty */
     ,(lambda () '())
     ; "WHERE" loc_def_list "END"
     ,(lambda (_1 _2 _3) `(DEFAULTS ,_2))

     ; loc_def_list:
     ; loc_def 
     ,(lambda (_1) (list _1))
     ; loc_def_list ',' loc_def 
     ,(lambda (_1 _2 _3) (append _1 (list _3)))

     ; loc_def:
     ; TOKENID params '=' expr locals
     ,(lambda (_1 _2 _3 _4 _5) (Syntax_Def _1 _2 _4 _5))

    ))



