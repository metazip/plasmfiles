;----------------------------------------
; new method to introduce C++ class in plt203 mzscheme
;
; ARGS OF make-primitive-class
;----------------------------------------
; (define (make-primitive-class 
;	   make-struct:prim     ; see below
;	   prim-init            ; primitive initializer: takes obj and list of name-arg pairs
;	   name                 ; symbol
;	   super                ; superclass
;	   init-arg-names       ; #f or list of syms and sym--value lists
;	   override-names       ; overridden method names
;	   new-names            ; new (public) method names
;	   override-methods     ; list of methods
;	   new-methods)         ; list of methods

(define pol-node%
	(let ([method-names '(assign-pol-complex)])
	(make-primitive-class
		(lambda (class prop:object dispatcher)
			(primitive-class-prepare-struct-type! pol-node-primitive-class prop:object class dispatcher))
		initialize-primitive-object  'pol-node%  object%  '(dimension) null  method-names null
		(map (lambda (name) (primitive-class-find-method pol-node-primitive-class name)) method-names))))

(define pol-complex%
	(let ([method-names '(get-npol-dim get-dpol-dim get-rep power insert-node get-first get-succ get-num scale-pol-complex translate-pol-complex rotate-pol-complex shear-pol-complex embed-pol-complex skeleton or and diff xor pdiff integrate join get-limits unmake-pol unmake-pol-f map-pol-complex map-pol-complex2 export-vrml-pol-complex export-svg-pol-complex export-flash-pol-complex dump-pol-complex dump-pol-complex-with-rep pol-complex-mat int-of-extr set-name-pol-complex delete-pol-complex copy-pol-complex bspize add-prop-pol-complex get-prop-pol-complex save-xml depol)])
	(make-primitive-class
		(lambda (class prop:object dispatcher)
			(primitive-class-prepare-struct-type! pol-complex-primitive-class prop:object class dispatcher))

		initialize-primitive-object 'pol-complex% object% '(dimension) null method-names null
		(map (lambda (name) (primitive-class-find-method pol-complex-primitive-class name)) method-names))))



