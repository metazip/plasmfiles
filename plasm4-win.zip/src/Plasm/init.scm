;==================================================
; MzPlasm
; Author:
;     Simone Portuesi
; DATE: January 2001
; Revision:
;     Stefano Francesi
; REVISION : August 2001
; Revision:
;     Giorgio Scorzelli
; REVISION : October 2002
;==================================================


(define *USE_GEOMETRY* '(expr_text ))     ; to disable C++ wrapper
(define *DEBUG* '())                      ; to show debug messages
(define *FREE-UNUSED-MEMORY* #f)          ; to automatically gargabe collecting
(define *DO-UNPRUNE* #f)                  ; used internally for BSPs
(define *PLASMLIBSDIR* "psmlib")          ; directory for libraries

; Per Stefano (NON ME LO TOCCARE!!!!)
(define *RET_VAL* #f)                     ; to always show scheme return value

(define (plasm-exception arg) 
  (display "uncaught exception: " )(display arg)(newline))

(current-library-collection-paths 
   (list (build-path (current-directory) "src" "mzscheme" "collects")))

(display "Loading file.ss...")
(require (lib "file.ss")) 
(display "done")
(newline)

(display "Loading pretty.ss...")
(require (lib "pretty.ss"))
(display "done")
(newline)

(display "Loading string.ss...")
(require (lib "string.ss"))
(display "done")
(newline)

(display "Loading url.ss...")
(require (lib  "url.ss" "net"))
(display "done")
(newline)

(display "Loading class.ss...")
(require (lib "class.ss"))
(display "done")
(newline)

(display "Loading list.ss...")
(require (lib "list.ss"))
(display "done")
(newline)

(define (eval_plasm arg) (Plasm_Parser arg) (display "plasm"))
(define (eval-plasm arg)  (Plasm_Parser arg) (display "plasm")) 
(define (plasm arg)  (Plasm_Parser arg) (display "plasm"))

(define (1+ aint) (+ 1 aint))
(define (1- aint) (- aint 1))

(display "Loading plt203.scm...")
(load (build-path "src" "Plasm" "plt203.scm"))
(display "done") 
(newline)

(display "Loading matrix.scm...")
(load (build-path "src" "Plasm" "matrix.scm"))
(display "done") 
(newline)

(display "Loading Syntax_Rules.scm...")
(load (build-path "src" "Plasm" "Syntax_Rules.scm"))
(display "done") 
(newline)

(display "Loading Printer.scm...")
(load (build-path "src" "Plasm" "Printer.scm"))
(display "done") 
(newline)

(display "Loading env.scm...")
(load (build-path "src" "Plasm" "env.scm"))
(display "done") 
(newline)
(display "Loading Properties.scm...")
(load (build-path "src" "Plasm" "Properties.scm"))
(display "done") 
(newline)

(display "Loading f_envs.scm...")
(load (build-path "src" "Plasm" "f_envs.scm"))
(display "done") 
(newline)

(display "Loading PlasmAnim.scm")
(load (build-path "src" "Plasm" "PlasmAnim.scm"))
(display "done") 
(newline)

(display "Loading remote_plasm.scm...")
(load (build-path "src" "Plasm" "remote_plasm.scm"))
(display "done") 
(newline)

; --------------------------------------------------
; insert here the loading of user-defined libraries 
; warning: symbols are not protected
; --------------------------------------------------

(load (build-path "psmlib" "variables.psm"))

(welcome (current-output-port))
