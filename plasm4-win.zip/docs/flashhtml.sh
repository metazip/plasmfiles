#!/bin/sh
if [ -z $1 ]; then {
   echo;
   echo "PLaSM 4.0 : HTML utility for FLASH files";
   echo "----------------------------------------";
   echo;
   echo "Usage: FLASHHTML basefile [width]";
   echo;
   echo "A file named basefile.html will be created to display a basefile.swf file";
   echo "The parameter width is optional (default = 600)";
   echo;
}
else {
   echo "Creating "$1".html ...";
   echo "<HTML>" >$1.html;
   echo "<HEAD><TITLE>" >>$1.html;
   echo "Flash file "$1".swf" >>$1.html;
   echo "</TITLE></HEAD>" >>$1.html;
   echo "<BODY>" >>$1.html;
   echo "<EMBED SRC=\""$1".swf\" TYPE=\"application/x-shockwave-flash\" PLAY=\"true\" LOOP=\"true\" QUALITY=\"high\"" >>$1.html;
   if [ -z $2 ]; then echo "WIDTH=\"600\">" >>$1.html;
   else echo "WIDTH=\""$2"\">" >>$1.html; fi
   echo "</EMBED>" >>$1.html;
   echo "</BODY>" >>$1.html;
   echo "</HTML>" >>$1.html;
   echo "Done";
}; fi
